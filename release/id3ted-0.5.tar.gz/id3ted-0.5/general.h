/* id3ted
 * general.h - header for general definitions
 * Copyright (C) 2008  Bert Muennich (muennich@informatik.hu-berlin.de)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 * USA.
 */

#ifndef __GENERAL_H__
#define __GENERAL_H__

#define PROGNAME "id3ted"
#define VERSION "0.5"

#define FCPY_BUFSIZE 512
#define FIELD_DELIM ':'

#ifdef DISABLE_UTF8
#define USE_UNICODE false
#define DEF_TSTR_ENC TagLib::String::Latin1
#else
#define USE_UNICODE true
#define DEF_TSTR_ENC TagLib::String::UTF8
#endif

extern const char *progname;

#endif /* __GENERAL_H__ */

