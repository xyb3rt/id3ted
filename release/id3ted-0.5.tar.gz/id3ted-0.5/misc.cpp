/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *  
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "misc.h"

const char* basename(const char *string) {
	const char *res;
	
	if (string == NULL) return NULL;
	res = strrchr(string, '/');
	if (res == NULL) return string;
	return ++res;
}

void printVersion() {
	size_t nIndex;
	cout << progname << " - command line id3 tag editor" << endl;
	cout << "version " << VERSION << endl;
	cout << "Written by Bert Muennich" << endl;
	cout << "Uses TagLib, written by Scott Wheeler" << endl;
}

void printUsage() {
	cout << "Usage: " << progname << " [OPTIONS]... FILES" << endl << endl;
	cout << "OPTIONS:" << endl;
	cout << "If a long option shows an argument as mandatory," << endl;
	cout << "then it is also mandatory for the equivalent short option." << endl << endl;
	cout << "  -h, --help             display this help and exit" << endl;
	cout << "  -f, --list-frames      display all possible frames for id3v2" << endl;
	cout << "  -G, --list-genres      list all id3v1 genres" << endl;
	cout << "  -v, --version          display version information and exit" << endl;
	cout << "  -i, --info             display general information for the file(s)" << endl;
	cout << "  -l, --list             list the tag(s) on the file(s)" << endl;
	cout << "  -L, --list-wd          same as -l, but list id3v2 frames with description" << endl;
	cout << "  -s, --strip-v1         strip id3v1 tag" << endl;
	cout << "  -S, --strip-v2         strip id3v2 tag" << endl;
	cout << "  -D, --delete-all       delete both id3v1 and id3v2 tag" << endl;
	cout << "  -1, --id3v1-only       write only id3v1 tag" << endl;
	cout << "  -2, --id3v2-only       write only id3v2 tag" << endl;
	cout << "  -3, --write-all        write both id3v1 and id3v2 tag" << endl;
	cout << "  -m, --org-move         when using -o, move files instead of copying them" << endl;
	cout << "  -F, --force            overwrite files without asking (-o, -x)" << endl;
	cout << "  -x, --extract-apics    extract all attached pictures" << endl;
	cout << "  -d, --delimiter C      set the delimiter for multiple field option" << endl
	<< "                         arguments to the given character (default is '" << FIELD_DELIM << "')" << endl;
	cout << "  -r, --remove FID       remove all frames with the given frame id" << endl;
	cout << "  -o, --organize PATTERN organize files into directory structure specified" << endl;
	cout << "                         by PATTERN (for supported wildcards see below)" << endl;
	cout << "  -a, --artist ARTIST    set the artist information" << endl;
	cout << "  -A, --album ALBUM      set the album title information" << endl;
	cout << "  -t, --title SONG       set the song title information" << endl;
	cout << "  -c, --comment COMMENT[" << FIELD_DELIM << "DESCRIPTION[" << FIELD_DELIM << "LANGUAGE]]"
	<< endl << "                         set the comment information (both"
	<< endl << "                         description and language optional)" << endl;    
	cout << "  -g, --genre NUM        set the genre number" << endl;
	cout << "  -T, --track NUM[/NUM]  set the track number/optional: total # of tracks" << endl;
	cout << "  -y, --year NUM         set the year" << endl << endl;
	cout << "The following wildcards are supported for the -o option path pattern:" << endl;
	cout << "    %a: Artist, %A: album, %t: title, %g: genre, %y: year," << endl;
	cout << "    %d: disc number, %n: track number" << endl << endl;
	cout << "You can set the value of many id3v2 frames by using \"--FID\"" << endl;
	cout << "For example: " << endl;
	cout << "    " << progname << " --TALB \"Sjofn\" file.mp3" << endl;
	cout << "would set the \"Album/Movie/Show title\" frame to \"Sjofn\"." << endl;
	cout << "Use `" << progname << " -f' to get a list of supported frames (marked with *)." << endl;
	cout << "There are some frames with multiple fields:" << endl;
	cout << "    --COMM COMMENT[" << FIELD_DELIM << "DESCRIPTION[" << FIELD_DELIM << "LANGUAGE]]" << endl;
	cout << "    --TXXX TEXT[" << FIELD_DELIM << "DESCRIPTION]" << endl;
	cout << "    --WXXX URL[" << FIELD_DELIM << "DESCRIPTION]" << endl;
	cout << "Only the first field is mandatory, the others are optional." << endl;
	cout << "When using --APIC the argument has to be a file!" << endl << endl;
	cout << "When using -x or --extract-apics all attached pictures are saved" << endl;
	cout << "as MP3FILENAME.apic-NUM.FORMAT in the current working directory." << endl;
}

const char* getMimeType(const char *file) {
	struct magic_set *magic;
	if ((magic = magic_open(MAGIC_MIME|MAGIC_CHECK)) == NULL) return NULL;
	if (magic_load(magic, NULL) != 0) return NULL;
	
	return magic_file(magic, file);
}

void trim_whitespace(std::string *str) {
	std::string::iterator str_iter = str->begin();
	std::string::reverse_iterator str_riter = str->rbegin() + 1;

	while (*str_iter == ' ' && str_iter != str->end())
		str_iter++;
	if (str_iter != str->begin())
		str->erase(str->begin(), str_iter);

	while (*str_riter == ' ' && str_riter != str->rend())
		str_riter++;
	if (str_riter != str->rbegin() + 1)
		str->erase(str_riter.base(), str->end());
}

int creat_dir_r(char *path) {
	char *curr = path;
	int ret = 0;
	struct stat f_stats;

	while (curr != NULL && ret == 0) {
		curr = strchr(curr + 1, '/');
		if (curr != NULL) *curr = '\0';
		if (access(path, F_OK) != 0 && errno == ENOENT) {
			if (mkdir(path, 0755) != 0) {
				cerr << progname << ": Could not create: " << path << endl;
				ret = -1;
			}
		} else if (stat(path, &f_stats) != 0 || !(f_stats.st_mode & S_IFDIR)) {
			cerr << progname << ": Not a directory: " << path << endl;
			ret = -1;
		}
		if (curr != NULL) *curr = '/';
	}

	return ret;
}

bool confirm_overwrite(const char *filename) {
	char *buf = (char*) malloc(10);
	bool ret = true;

	if (buf == NULL) {
		cerr << progname << ": Could not allocate needed memory" << endl;
		exit(2);
	}

	while (1) {
		cout << "overwrite " << filename << "? [yN] ";
		char *userIn = fgets(buf, 10, stdin);

		if (userIn == NULL) {
			continue;
		}

		if (strcmp(buf, "\n") == 0 || strcmp(buf, "n\n") == 0 || strcmp(buf, "N\n") == 0) {
			ret = false;
			break;
		} else if (strcmp(buf, "y\n") == 0 || strcmp(buf, "Y\n") == 0) {
			break;
		}
	}
	
	if (buf != NULL) free(buf);
	
	return ret;
}

