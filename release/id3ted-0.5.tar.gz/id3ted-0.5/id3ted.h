/* id3ted
 * id3ted.h - header for main file
 * Copyright (C) 2008  Bert Muennich (muennich@informatik.hu-berlin.de)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 * USA.
 */

#ifndef __ID3TED_H__
#define __ID3TED_H__

#include <cstdlib>
#include <cstdio>
#include <string>
#include <list>
#include <getopt.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <taglib/tbytevector.h>
#include <taglib/tstring.h>
#include <taglib/id3v1tag.h>
#include <taglib/id3v1genres.h>
#include <taglib/id3v2tag.h>
#include <taglib/id3v2frame.h>
#include <taglib/id3v2header.h>
#include <taglib/mpegfile.h>
#include <taglib/attachedpictureframe.h>
#include <taglib/commentsframe.h>
#include <taglib/textidentificationframe.h>
#include <taglib/urllinkframe.h>
#include <taglib/unsynchronizedlyricsframe.h>

#include "general.h"
#include "list.h"
#include "misc.h"

using namespace std;
using namespace TagLib;

const char *progname;
const char *colorRed;
const char *colorGreen;
const char *colorYellow;
const char *colorBlue;
const char *colorMagenta;
const char *colorCyan;
const char *colorOff;

typedef struct frame_info {
	const char *id;
	enum ID3_FrameID fid;
	const char *data;
	ByteVector *dataExt;
} frame_info_t;

int iLongOpt, optFrameID;
static struct option long_options[] = {
	// help and info
	{ "help",          no_argument, &iLongOpt, 'h' },
	{ "list-frames",   no_argument, &iLongOpt, 'f' },
	{ "list-genres",   no_argument, &iLongOpt, 'G' },
	{ "version",       no_argument, &iLongOpt, 'v' },
	// list / remove / convert
	{ "info",          no_argument, &iLongOpt, 'i' },
	{ "list",          no_argument, &iLongOpt, 'l' },
	{ "list-wd",       no_argument, &iLongOpt, 'L' },
	{ "strip-v1",      no_argument, &iLongOpt, 's' },
	{ "strip-v2",      no_argument, &iLongOpt, 'S' },
	{ "delete-all",    no_argument, &iLongOpt, 'D' },
	{ "id3v1-only",    no_argument, &iLongOpt, '1' },
	{ "id3v2-only",    no_argument, &iLongOpt, '2' },
	{ "write-all",     no_argument, &iLongOpt, '3' },
	{ "org-move",      no_argument, &iLongOpt, 'm' },
	{ "force",         no_argument, &iLongOpt, 'F' },
	{ "extract-apics", no_argument, &iLongOpt, 'x' },
	{ "delimiter",     required_argument, &iLongOpt, 'd' },
	{ "organize",      required_argument, &iLongOpt, 'o' },
	{ "remove",        required_argument, &iLongOpt, 'r' },
	// infomation to tag
	{ "artist",        required_argument, &iLongOpt, 'a' },
	{ "album",         required_argument, &iLongOpt, 'A' },
	{ "title",         required_argument, &iLongOpt, 't' },
	{ "comment",       required_argument, &iLongOpt, 'c' },
	{ "genre",         required_argument, &iLongOpt, 'g' },
	{ "track",         required_argument, &iLongOpt, 'T' },
	{ "year",          required_argument, &iLongOpt, 'y' },
	// id3v2 frame ids for direct tagging
  //{ frameTable[1].id,  required_argument, &optFrameID, FID3_AENC },
  { frameTable[2].id,  required_argument, &optFrameID, FID3_APIC },
  //{ frameTable[3].id,  required_argument, &optFrameID, FID3_ASPI },
  { frameTable[4].id,  required_argument, &optFrameID, FID3_COMM },
  //{ frameTable[5].id,  required_argument, &optFrameID, FID3_COMR },
  //{ frameTable[6].id,  required_argument, &optFrameID, FID3_ENCR },
  //{ frameTable[7].id,  required_argument, &optFrameID, FID3_EQU2 },
  //{ frameTable[8].id,  required_argument, &optFrameID, FID3_EQUA },
  //{ frameTable[9].id,  required_argument, &optFrameID, FID3_ETCO },
  //{ frameTable[10].id, required_argument, &optFrameID, FID3_GEOB },
  //{ frameTable[11].id, required_argument, &optFrameID, FID3_GRID },
  //{ frameTable[12].id, required_argument, &optFrameID, FID3_IPLS },
  //{ frameTable[13].id, required_argument, &optFrameID, FID3_LINK },
  //{ frameTable[14].id, required_argument, &optFrameID, FID3_MCDI },
  //{ frameTable[15].id, required_argument, &optFrameID, FID3_MLLT },
  //{ frameTable[16].id, required_argument, &optFrameID, FID3_OWNE },
  //{ frameTable[17].id, required_argument, &optFrameID, FID3_PRIV },
  { frameTable[18].id, required_argument, &optFrameID, FID3_PCNT },
  //{ frameTable[19].id, required_argument, &optFrameID, FID3_POPM },
  //{ frameTable[20].id, required_argument, &optFrameID, FID3_POSS },
  { frameTable[21].id, required_argument, &optFrameID, FID3_RBUF },
  //{ frameTable[22].id, required_argument, &optFrameID, FID3_RVA2 },
  //{ frameTable[23].id, required_argument, &optFrameID, FID3_RVAD },
  //{ frameTable[24].id, required_argument, &optFrameID, FID3_RVRB },
  //{ frameTable[25].id, required_argument, &optFrameID, FID3_SEEK },
  //{ frameTable[26].id, required_argument, &optFrameID, FID3_SIGN },
  //{ frameTable[27].id, required_argument, &optFrameID, FID3_SYLT },
  //{ frameTable[28].id, required_argument, &optFrameID, FID3_SYTC },
  { frameTable[29].id, required_argument, &optFrameID, FID3_TALB },
  { frameTable[30].id, required_argument, &optFrameID, FID3_TBPM },
  { frameTable[31].id, required_argument, &optFrameID, FID3_TCOM },
  { frameTable[32].id, required_argument, &optFrameID, FID3_TCON },
  { frameTable[33].id, required_argument, &optFrameID, FID3_TCOP },
  //{ frameTable[34].id, required_argument, &optFrameID, FID3_TDAT },
  { frameTable[35].id, required_argument, &optFrameID, FID3_TDEN },
  { frameTable[36].id, required_argument, &optFrameID, FID3_TDLY },
  { frameTable[37].id, required_argument, &optFrameID, FID3_TDOR },
  { frameTable[38].id, required_argument, &optFrameID, FID3_TDRC },
  { frameTable[39].id, required_argument, &optFrameID, FID3_TDRL },
  { frameTable[40].id, required_argument, &optFrameID, FID3_TDTG },
  { frameTable[41].id, required_argument, &optFrameID, FID3_TENC },
  { frameTable[42].id, required_argument, &optFrameID, FID3_TEXT },
  { frameTable[43].id, required_argument, &optFrameID, FID3_TFLT },
  //{ frameTable[44].id, required_argument, &optFrameID, FID3_TIME },
  //{ frameTable[45].id, required_argument, &optFrameID, FID3_TIPL },
  { frameTable[46].id, required_argument, &optFrameID, FID3_TIT1 },
  { frameTable[47].id, required_argument, &optFrameID, FID3_TIT2 },
  { frameTable[48].id, required_argument, &optFrameID, FID3_TIT3 },
  { frameTable[49].id, required_argument, &optFrameID, FID3_TKEY },
  { frameTable[50].id, required_argument, &optFrameID, FID3_TLAN },
  { frameTable[51].id, required_argument, &optFrameID, FID3_TLEN },
  { frameTable[52].id, required_argument, &optFrameID, FID3_TMCL },
  { frameTable[53].id, required_argument, &optFrameID, FID3_TMED },
  { frameTable[54].id, required_argument, &optFrameID, FID3_TMOO },
  { frameTable[55].id, required_argument, &optFrameID, FID3_TOAL },
  { frameTable[56].id, required_argument, &optFrameID, FID3_TOFN },
  { frameTable[57].id, required_argument, &optFrameID, FID3_TOLY },
  { frameTable[58].id, required_argument, &optFrameID, FID3_TOPE },
  { frameTable[59].id, required_argument, &optFrameID, FID3_TORY },
  { frameTable[60].id, required_argument, &optFrameID, FID3_TOWN },
  { frameTable[61].id, required_argument, &optFrameID, FID3_TPE1 },
  { frameTable[62].id, required_argument, &optFrameID, FID3_TPE2 },
  { frameTable[63].id, required_argument, &optFrameID, FID3_TPE3 },
  { frameTable[64].id, required_argument, &optFrameID, FID3_TPE4 },
  { frameTable[65].id, required_argument, &optFrameID, FID3_TPOS },
  { frameTable[66].id, required_argument, &optFrameID, FID3_TPRO },
  { frameTable[67].id, required_argument, &optFrameID, FID3_TPUB },
  { frameTable[68].id, required_argument, &optFrameID, FID3_TRCK },
  //{ frameTable[69].id, required_argument, &optFrameID, FID3_TRDA },
  { frameTable[70].id, required_argument, &optFrameID, FID3_TRSN },
  { frameTable[71].id, required_argument, &optFrameID, FID3_TRSO },
  //{ frameTable[72].id, required_argument, &optFrameID, FID3_TSIZ },
  { frameTable[73].id, required_argument, &optFrameID, FID3_TSOA },
  { frameTable[74].id, required_argument, &optFrameID, FID3_TSOP },
  { frameTable[75].id, required_argument, &optFrameID, FID3_TSOT },
  { frameTable[76].id, required_argument, &optFrameID, FID3_TSRC },
  { frameTable[77].id, required_argument, &optFrameID, FID3_TSSE },
  { frameTable[78].id, required_argument, &optFrameID, FID3_TSST },
  { frameTable[79].id, required_argument, &optFrameID, FID3_TXXX },
  //{ frameTable[80].id, required_argument, &optFrameID, FID3_TYER },
  //{ frameTable[81].id, required_argument, &optFrameID, FID3_UFID },
  { frameTable[82].id, required_argument, &optFrameID, FID3_USER },
  { frameTable[83].id, required_argument, &optFrameID, FID3_USLT },
  { frameTable[84].id, required_argument, &optFrameID, FID3_WCOM },
  { frameTable[85].id, required_argument, &optFrameID, FID3_WCOP },
  { frameTable[86].id, required_argument, &optFrameID, FID3_WOAF },
  { frameTable[87].id, required_argument, &optFrameID, FID3_WOAR },
  { frameTable[88].id, required_argument, &optFrameID, FID3_WOAS },
  { frameTable[89].id, required_argument, &optFrameID, FID3_WORS },
  { frameTable[90].id, required_argument, &optFrameID, FID3_WPAY },
  { frameTable[91].id, required_argument, &optFrameID, FID3_WPUB },
  { frameTable[92].id, required_argument, &optFrameID, FID3_WXXX },
	{ 0, 0, 0, 0 },
};

#endif /* __ID3TED_H__ */
