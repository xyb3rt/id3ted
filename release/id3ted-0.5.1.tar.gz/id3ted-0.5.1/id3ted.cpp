/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *  
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "id3ted.h"

int main(int argc, char **argv) {
	int updFlag = 3;
	bool updFlagCheck = false;

	int versionToStrip = 0;
	int argCounter = 0, ii, iOpt, optionIndex;
	char fdelim = FIELD_DELIM;
	bool haveToWriteFile = false, extractAPICs = false;
	bool haveToListTags = false, listV2WithDesc = false, haveToShowInfo = false;
	const char *orgPattern = NULL;
	bool forceOverwrite = false, orgMove = false;

	std::list<char*> framesToDel;
	std::list<frame_info_t> framesToMod;

	progname = basename(argv[0]);
	if (progname == NULL) progname = "id3ted";

	while (true) {
		optionIndex = 0;
		iLongOpt = 0;
		optFrameID = FID3_XXXX;

		iOpt = getopt_long(argc, argv, "hfGvilLsSD123mFxd:o:r:a:A:t:c:g:y:T:", long_options, &optionIndex);

		if (iOpt == -1 && argCounter == 0) {
			cout << progname << ": missing arguments" << endl;
			cout << "Try `" << progname << " --help' for more information" << endl;
			exit(0);
		} else if (iOpt == -1) {
			break;
		}
		if (iOpt == 0) {
			iOpt = iLongOpt;
		}
		argCounter++;

		switch (iOpt) {
			case 0: {
				frame_info_t newF2MEntry;
				newF2MEntry.id = textFrameID((ID3_FrameID) optFrameID);
				newF2MEntry.fid = (enum ID3_FrameID) optFrameID;
				newF2MEntry.data = optarg;
				framesToMod.push_back(newF2MEntry);
				haveToWriteFile = true;
				break;
			}
			case '?':
			case ':': {
				cout << "Try `" << progname << " --help' for more information" << endl;
				exit(1);
			}
			case 'h': {
				printUsage();
				exit(0);
			}
			case 'f': {
				printFrameHelp();
				exit(0);
			}
			case 'G': {
				printGenreList();
				exit(0);
			}
			case 'v': {
				printVersion();
				exit(0);
			}
			case 'i': {
				haveToShowInfo = true;
				break;
			}
			case 'l': {
				haveToListTags = true;
				break;
			}
			case 'L': {
				haveToListTags = true;
				listV2WithDesc = true;
				break;
			}
			case 's': {
				versionToStrip |= 1;
				haveToWriteFile = true;
				break;
			}
			case 'S': {
				versionToStrip |= 2;
				haveToWriteFile = true;
				break;
			}
			case 'D': {
				versionToStrip = 3;
				haveToWriteFile = true;
				break;
			}
			// which version of tag should be changed
			case '1': {
				updFlag = 1;
				updFlagCheck = true;
				haveToWriteFile = true;
				break;
			}
			case '2': {
				updFlag = 2;
				updFlagCheck = true;
				haveToWriteFile = true;
				break;
			}
			case '3': {
				updFlag = 3;
				updFlagCheck = true;
				haveToWriteFile = true;
				break;
			}
			case 'm': {
				orgMove = true;
				break;
			}
			case 'F': {
				forceOverwrite = true;
				break;
			}
			// Tagging stuff
			case 'x': {
				extractAPICs = true;
				break;
			}
			case 'd': {
				if (strlen(optarg) == 1) {
					fdelim = optarg[0];
				} else {
					cerr << "The argument of -d/--delimiter has to be a single character!" << endl
					<< "Try '" << progname << " --help' for more information" << endl;
					exit(2);
				}
				break;
			}
			case 'r': {
				framesToDel.push_back(optarg);
				haveToWriteFile = true;
				break;
			}
			case 'o': {
				orgPattern = optarg;
				break;
			}
			case 'a': {
				frame_info_t newF2MEntry;
				newF2MEntry.id = "TPE1";
				newF2MEntry.fid = FID3_TPE1;
				newF2MEntry.data = optarg;
				framesToMod.push_back(newF2MEntry);
				haveToWriteFile = true;
				break;
			}
			case 'A': {
				frame_info_t newF2MEntry;
				newF2MEntry.id = "TALB";
				newF2MEntry.fid = FID3_TALB;
				newF2MEntry.data = optarg;
				framesToMod.push_back(newF2MEntry);
				haveToWriteFile = true;
				break;
			}
			case 't': {
				frame_info_t newF2MEntry;
				newF2MEntry.id = "TIT2";
				newF2MEntry.fid = FID3_TIT2;
				newF2MEntry.data = optarg;
				framesToMod.push_back(newF2MEntry);
				haveToWriteFile = true;
				break;
			}
			case 'c': {
				frame_info_t newF2MEntry;
				newF2MEntry.id = "COMM";
				newF2MEntry.fid = FID3_COMM;
				newF2MEntry.data = optarg;
				framesToMod.push_back(newF2MEntry);
				haveToWriteFile = true;
				break;
			}
			case 'g': {
				frame_info_t newF2MEntry;
				newF2MEntry.id = "TCON";
				newF2MEntry.fid = FID3_TCON;
				newF2MEntry.data = optarg;
				framesToMod.push_back(newF2MEntry);
				haveToWriteFile = true;
				break;
			}
			case 'T': {
				frame_info_t newF2MEntry;
				newF2MEntry.id = "TRCK";
				newF2MEntry.fid = FID3_TRCK;
				newF2MEntry.data = optarg;
				framesToMod.push_back(newF2MEntry);
				haveToWriteFile = true;
				break;
			}
			case 'y': {
				frame_info_t newF2MEntry;
				newF2MEntry.id = "TYER";
				newF2MEntry.fid = FID3_TYER;
				newF2MEntry.data = optarg;
				framesToMod.push_back(newF2MEntry);
				haveToWriteFile = true;
				break;
			}
			default: {
				cerr << "This isn't supposed to happen!" << endl;
				exit(1);
			}
		}
	}
	
	if (optind == argc) {
		cerr << "No file to work on!" << endl;
		exit(1);
	}

	for (int currIndex = optind; (unsigned int) currIndex < argc; currIndex++) {
		bool hasChanged = false;

		if (!TagLib::File::isReadable(argv[currIndex])) {
			cerr << progname << ": " << argv[currIndex] << ": Could not open file for reading" << endl;
			continue;
		}
		if (haveToWriteFile && !TagLib::File::isWritable(argv[currIndex])) {
			cerr << progname << ": " << argv[currIndex] << ": Could not open file for writing" << endl;
			continue;
		}

		MPEG::File mp3File(argv[currIndex]);
		ID3v1::Tag *ID3v1Tag = mp3File.ID3v1Tag();
		ID3v2::Tag *ID3v2Tag = mp3File.ID3v2Tag(true);
		Tag *ID3Tag = mp3File.tag();

		bool hasID3v1Tag = (ID3v1Tag && !ID3v1Tag->isEmpty());
		if (!updFlagCheck) {
			// if -1, -2 or -3 options are not given on command line,
			// and file has only v1 or v2 tag, update only this
			updFlag = 3;
			if (!hasID3v1Tag) {
				updFlag = 2;
			} else if (!ID3v2Tag || ID3v2Tag->isEmpty()) {
				updFlag = 1;
			}
		}
			
		//extract APICs
		if (extractAPICs) {
			const char *infname = basename(argv[currIndex]);
			int picNum = 0, infnlen = strlen(infname);
			char *outftype, *outfile = NULL;
			const char *mimetype;
			FILE *fptr;
			
			ID3v2::FrameList apicList = ID3v2Tag->frameListMap()["APIC"];
			ID3v2::FrameList::ConstIterator it = apicList.begin();
			for (; it != apicList.end() && picNum <= 20; it++) {
				picNum++;
				ID3v2::AttachedPictureFrame *apf = dynamic_cast<ID3v2::AttachedPictureFrame*>(*it);
				if (apf == NULL) continue;
				mimetype = apf->mimeType().toCString();
				outftype = strrchr(mimetype, '/');
				if (outftype != NULL) {
					outftype++;
				} else {
					outftype = "bin";
				}

				if (picNum < 2) {
					if ((outfile = (char*) malloc(infnlen + 14)) == NULL) {
						cerr << progname << ": Could not allocate needed memory" << endl;
						exit(2);
					}
					strcpy(outfile, infname);
					strcat(outfile, ".apic-");
					sprintf(outfile + infnlen + 6, "%02d", picNum);
					strcat(outfile, ".");
					strcat(outfile, outftype);
				} else {
					sprintf(outfile + infnlen + 6, "%02d", picNum);
					outfile[infnlen + 8] = '.';
					strcpy(outfile + infnlen + 9, outftype);
				}

				bool writeOK = true;
				if (access(outfile, F_OK) == 0) {
					if (!forceOverwrite && !confirm_overwrite(outfile)) {
						writeOK = false;
					}
				}
						
				if (writeOK) {
					if ((fptr = fopen(outfile, "w+")) == NULL) continue;
					ByteVector picData = apf->picture();
					unsigned int dataLen = picData.size();
					fwrite(picData.data(), dataLen, 1, fptr);
					fclose(fptr);
				}
			}

			if (outfile != NULL) free(outfile);
		} // extract APICs

		// delete frames with given fids
		if (!framesToDel.empty()) hasChanged = true;
		std::list<char*>::const_iterator f2d_iter = framesToDel.begin();
		for (; f2d_iter != framesToDel.end(); f2d_iter++) {
			switch (frameID(*f2d_iter)) {
				case FID3_TALB: {
					ID3Tag->setAlbum(TagLib::String::null);
					break;
				}
				case FID3_TCON: {
					ID3Tag->setGenre(TagLib::String::null);
					break;
				}
				case FID3_TIT2: {
					ID3Tag->setTitle(TagLib::String::null);
					break;
				}
				case FID3_TPE1: {
					ID3Tag->setArtist(TagLib::String::null);
					break;
				}
				case FID3_TRCK: {
					ID3Tag->setTrack(0);
					break;
				}
				case FID3_TDRC:
				case FID3_TYER: {
					ID3Tag->setYear(0);
					break;
				}
				case FID3_COMM: {
					ID3v1Tag->setComment(TagLib::String::null);
				}
				default: {
					ID3v2Tag->removeFrames(*f2d_iter);
					break;
				}
			}
		}

		// loop through the frames for adding/modifying
		if (!framesToMod.empty()) hasChanged = true;
		std::list<frame_info_t>::iterator f2m_iter = framesToMod.begin();
		while (f2m_iter != framesToMod.end()) {
			bool TypeOne = false;
			ID3v2::FrameList oldList = ID3v2Tag->frameListMap()[f2m_iter->id];
			TagLib::String input(f2m_iter->data, DEF_TSTR_ENC);

			switch(f2m_iter->fid) {
				case FID3_APIC: {
					if (currIndex == optind) {
						const char *mimetype;
						FILE *fptr;

						fptr = fopen(f2m_iter->data, "r");
						if (fptr == NULL) {
							fprintf(stderr, "%s: %s: ", progname, f2m_iter->data);
							perror(NULL);
							std::list<frame_info_t>::iterator f2m_iter_temp = f2m_iter++;
							framesToMod.erase(f2m_iter_temp);
							continue;
						}
					
						mimetype = getMimeType(f2m_iter->data);
						char *mttemp = strstr(mimetype, "image");
						if (mttemp == NULL) {
							cerr << progname << ": " << f2m_iter->data << ": Wrong mime-type: " << mimetype << "! Not an image, not attached." << endl;
							std::list<frame_info_t>::iterator f2m_iter_temp = f2m_iter++;
							framesToMod.erase(f2m_iter_temp);
							continue;
						}
					
						fseek(fptr, 0, SEEK_END);
						size_t fileSize = ftell(fptr);
						fseek(fptr, 0, SEEK_SET);
						char* picFile = new char[fileSize];
						if (picFile != NULL) {
							fread(picFile, 1, fileSize, fptr);
							f2m_iter->dataExt = new ByteVector(picFile, fileSize);
							f2m_iter->data = mimetype;
							delete [] picFile;
						} else {
							std::list<frame_info_t>::iterator f2m_iter_temp = f2m_iter++;
							framesToMod.erase(f2m_iter_temp);
							continue;
						}
						fclose(fptr);
					}

					ID3v2::AttachedPictureFrame *apf = new ID3v2::AttachedPictureFrame();
					apf->setMimeType(f2m_iter->data);
					apf->setType((ID3v2::AttachedPictureFrame::Type) 3);
					apf->setPicture(*(f2m_iter->dataExt));
					ID3v2Tag->addFrame(apf);

					break;
				}
				case FID3_TALB: {
					ID3Tag->setAlbum(input);
					break;
				}
				case FID3_PCNT:
				case FID3_RBUF:
				case FID3_TBPM:
				case FID3_TCOM:
				case FID3_TCOP:
				case FID3_TDEN:
				case FID3_TDLY:
				case FID3_TDOR:
				case FID3_TDRL:
				case FID3_TDTG:
				case FID3_TENC:
				case FID3_TEXT:
				case FID3_TFLT:
				case FID3_TIT1:
				case FID3_TIT3:
				case FID3_TKEY:
				case FID3_TLAN:
				case FID3_TLEN:
				case FID3_TMCL:
				case FID3_TMED:
				case FID3_TMOO:
				case FID3_TOAL:
				case FID3_TOFN:
				case FID3_TOLY:
				case FID3_TOPE:
				case FID3_TOWN:
				case FID3_TPE2:
				case FID3_TPE3:
				case FID3_TPE4:
				case FID3_TPOS:
				case FID3_TPRO:
				case FID3_TPUB:
				case FID3_TRSN:
				case FID3_TRSO:
				case FID3_TSOA:
				case FID3_TSOP:
				case FID3_TSOT:
				case FID3_TSRC:
				case FID3_TSSE:
				case FID3_TSST:
				case FID3_USER: {
					if (strlen(f2m_iter->data) > 0) {
						if (!oldList.isEmpty()) {
							oldList.front()->setText(input);
						} else {
							ID3v2::TextIdentificationFrame *tf = new ID3v2::TextIdentificationFrame(f2m_iter->id);
							tf->setText(input);
							ID3v2Tag->addFrame(tf);
						}
					} else if (!oldList.isEmpty()) {
						ID3v2Tag->removeFrame(oldList.front());
					}

					break;
				}
				case FID3_USLT: {
					TypeOne = true;
				}
				case FID3_COMM: {
					bool setV1Comm = false;
					String text, description, language;
					int inputLength = input.size();
					int textLength = inputLength, descriptionLength = 0;
					int descriptionIdx = 0, languageIdx = 0;

					descriptionIdx = input.find(fdelim, 0);
					if (descriptionIdx != -1) {
						textLength = descriptionIdx++;
						descriptionLength = inputLength - descriptionIdx;
						languageIdx = input.find(fdelim, descriptionIdx);
						if (languageIdx != -1) {
							descriptionLength = languageIdx++ - descriptionIdx;
							language = input.substr(languageIdx, inputLength - languageIdx).stripWhiteSpace();
						}
						description = input.substr(descriptionIdx, descriptionLength);
					}
					text = input.substr(0, textLength);
					if (descriptionIdx <= 0 && !TypeOne) setV1Comm = (updFlag & 1)  || hasID3v1Tag;
					if (language.size() != 3) language = "XXX";

					bool alreadyIn = false;
					ID3v2::CommentsFrame *cf;
					ID3v2::UnsynchronizedLyricsFrame *ulf;

					ID3v2::FrameList::ConstIterator it = oldList.begin();
					while (it != oldList.end()) {
						if (TypeOne) {
							if ((ulf = dynamic_cast<ID3v2::UnsynchronizedLyricsFrame*>(*it)) == NULL) continue;
							if (ulf->language() == "" || ulf->language().isEmpty() || ulf->language().toUInt() == 0) {
								ulf->setLanguage("XXX");
							}
							alreadyIn = description == ulf->description() && language == ulf->language();
						} else {	
							if ((cf = dynamic_cast<ID3v2::CommentsFrame*>(*it)) == NULL) continue;
							if (cf->language() == "" || cf->language().isEmpty() || cf->language().toUInt() == 0) {
								cf->setLanguage("XXX");
							}
							alreadyIn = description == cf->description() && language == cf->language();
						}

						if (alreadyIn) {
							if (textLength > 0) {
								(*it)->setText(text);
							} else {
								ID3v2Tag->removeFrame(*it);
							}
							break;
						}
						it++;
					}

					if (setV1Comm) {
						ID3v1Tag->setComment(text);
					}

					if (!alreadyIn && textLength > 0) {
						if (TypeOne) {
							ulf = new ID3v2::UnsynchronizedLyricsFrame((enum TagLib::String::Type) 0);
							ulf->setText(text);
							if (descriptionLength > 0) ulf->setDescription(description);
							ulf->setLanguage(language.toCString());
							ID3v2Tag->addFrame(ulf);
						} else {
							cf = new ID3v2::CommentsFrame((enum TagLib::String::Type) 0);
							cf->setText(text);
							if (descriptionLength > 0) cf->setDescription(description);
							cf->setLanguage(language.toCString());
							ID3v2Tag->addFrame(cf);
						} 
					}

					break;
				}
				case FID3_TCON: {
					ID3Tag->setGenre(input);
					break;
				}
				case FID3_TIT2: {
					ID3Tag->setTitle(input);
					break;
				}
				case FID3_TPE1: {
					ID3Tag->setArtist(input);
					break;
				}
				case FID3_TRCK: {
					ID3v1Tag->setTrack(0);
					if (strlen(f2m_iter->data) > 0) {
						if (!oldList.isEmpty()) {
							oldList.front()->setText(input);
						} else {
							ID3v2::TextIdentificationFrame *tif = new ID3v2::TextIdentificationFrame(f2m_iter->id);
							tif->setText(input);
							ID3v2Tag->addFrame(tif);
						}
					} else if (!oldList.isEmpty()) {
						ID3v2Tag->removeFrame(oldList.front());
					}
					
					break;
				}
				case FID3_TDRC:
				case FID3_TYER: {
					ID3Tag->setYear(atoi(f2m_iter->data));
					break;
				}
				case FID3_WCOM:
				case FID3_WCOP:
				case FID3_WOAF:
				case FID3_WOAR:
				case FID3_WOAS:
				case FID3_WORS:
				case FID3_WPAY:
				case FID3_WPUB: {
					if (strlen(f2m_iter->data) > 0) {
						if (!oldList.isEmpty()) {
							oldList.front()->setText(input);
						} else {
							ID3v2::UrlLinkFrame *ulf = new ID3v2::UrlLinkFrame(f2m_iter->id);
							ulf->setUrl(input);
							ID3v2Tag->addFrame(ulf);
						}
					} else if (!oldList.isEmpty()) {
						ID3v2Tag->removeFrame(oldList.front());
					}

					break;
				}
				case FID3_TXXX: {
					TypeOne = true;
				}
				case FID3_WXXX: {
					String description;
					int inputLength = input.size();
					int textLength = inputLength, descriptionLength = 0;
					int descriptionIdx = 0;

					descriptionIdx = input.find(fdelim, 0);
					if (descriptionIdx != -1) {
						textLength = descriptionIdx++;
						descriptionLength = inputLength - descriptionIdx;
						description = input.substr(descriptionIdx, descriptionLength);
					} else if (TypeOne) {
						description = input.substr(0, textLength);
					}

					bool alreadyIn = false;
					ID3v2::UserUrlLinkFrame *uulf;
					ID3v2::UserTextIdentificationFrame *utif;

					ID3v2::FrameList::ConstIterator it = oldList.begin();
					while (it != oldList.end()) {
						if (TypeOne) {
							if ((utif = dynamic_cast<ID3v2::UserTextIdentificationFrame*>(*it)) == NULL) continue;
							alreadyIn = description == utif->description();
						} else {
							if ((uulf = dynamic_cast<ID3v2::UserUrlLinkFrame*>(*it)) == NULL) continue;
							alreadyIn = description == uulf->description();
						}
						if (alreadyIn) {
							if (textLength > 0) {
								(*it)->setText(input.substr(0, textLength));
							} else {
								ID3v2Tag->removeFrame(*it);
							}
							break;
						}
						it++;
					}
					
					if (!alreadyIn && textLength > 0) {
						if (TypeOne) {
							utif = new ID3v2::UserTextIdentificationFrame((enum TagLib::String::Type) 0);
							if (descriptionLength > 0) utif->setDescription(description);
							utif->setText(input.substr(0, textLength));
							ID3v2Tag->addFrame(utif);
						} else {
							uulf = new ID3v2::UserUrlLinkFrame((enum TagLib::String::Type) 0);
							if (descriptionLength > 0) uulf->setDescription(description);
							uulf->setUrl(input.substr(0, textLength));
							ID3v2Tag->addFrame(uulf);
						}
					}

					break;
				}
			}

			f2m_iter++;
		}

		// save the specified tags to the file
		if (hasChanged || updFlagCheck) {
			// bug in TagLib?: deleting last frame in id3v2 tag somewhere in the code above
			// and then saving file here causes the recovery of this last deleted frame. 
			// solution: strip the whole tag if it is empty before writing file!
			if ((updFlag & 2) && ID3v2Tag->isEmpty()) mp3File.strip(2);
			mp3File.save(updFlag, false);
		}

		// delete whole tag version
		if (versionToStrip > 0) {
			if (!mp3File.strip(versionToStrip)) {
				cerr << progname << ": " << argv[currIndex] << ": Could not delete id3 tag" << endl;
			}
		}

		if (haveToShowInfo || haveToListTags) {
			cout << argv[currIndex] << ":" << endl;
		}

		if (haveToShowInfo) {
			showInfo(&mp3File);
		}

		if (haveToListTags) {
			listTags(&mp3File, listV2WithDesc);
		}

		if ((haveToShowInfo || haveToListTags) && currIndex < argc - 1) {
			cout << endl;
		}

		if (orgPattern != NULL) {
			// organize file in directory structure defined by pattern

			if (orgPattern[strlen(orgPattern) - 1] == '/') {
				cout << "-o is ignored, because file pattern ends with a slash" << endl;
				orgPattern = NULL;
				continue;
			}

			bool writeOK = true;
			bool wcardPresent = false;

			std::string *curr;
			std::string *path = new std::string(orgPattern);
			char *dirname = NULL, *filename = NULL, *buffer = NULL, *tmpBuf;
			if ((tmpBuf = (char*) malloc(5)) == NULL) {
				cerr << progname << ": Could not allocate needed memory" << endl;
				exit(2);
			}

			std::string::iterator path_iter = path->begin();
			while (path_iter != path->end()) {

				if (*path_iter == '%') {
					switch(*(path_iter + 1)) {
						case 'a': {
							TagLib::String artist = ID3Tag->artist();
							if (artist == TagLib::String::null) {
								curr = new std::string("Unknown Artist");
							} else {
								curr = new std::string(artist.toCString(USE_UNICODE));
							}
							break;
						}
						case 'A': {
							TagLib::String album = ID3Tag->album();
							if (album == TagLib::String::null) {
								curr = new std::string("Unknown Album");
							} else {
								curr = new std::string(album.toCString(USE_UNICODE));
							}
							break;
						}
						case 't': {
							TagLib::String title = ID3Tag->title();
							if (title == TagLib::String::null) {
								curr = new std::string("Unknown Title");
							} else {
								curr = new std::string(title.toCString(USE_UNICODE));
							}
							break;
						}
						case 'g': {
							TagLib::String genre = ID3Tag->genre();
							if (genre == TagLib::String::null) {
								curr = new std::string("");
							} else {
								curr = new std::string(genre.toCString(USE_UNICODE));
							}
							break;
						}
						case 'y': {
							unsigned int year = ID3Tag->year();
							if (!year) {
								curr = new std::string("");
							} else {
								snprintf(tmpBuf, 5, "%d", year);
								curr = new std::string(tmpBuf);
							}
							break;
						}
						case 'n': {
							unsigned int track = ID3Tag->track();
							if (!track) {
								curr = new std::string("");
							} else {
								snprintf(tmpBuf, 5, "%02d", track);
								curr = new std::string(tmpBuf);
							}
							break;
						}
						case 'd': {
							int discNum = 0;
							ID3v2::FrameList discNumList = ID3v2Tag->frameListMap()["TPOS"];
							if (!discNumList.isEmpty()) {
								TagLib::String dNum = discNumList.front()->toString();
								discNum = dNum.toInt();
							}
							if (!discNum) {
								curr = new std::string("");
							} else {
								snprintf(tmpBuf, 5, "%d", discNum);
								curr = new std::string(tmpBuf);
							}
							break;
						}
					}

					if (curr != NULL) {
						int path_idx = path_iter - path->begin();
						wcardPresent = true;

						path->replace(path_iter, path_iter + 2, *curr);
						path_iter = path->begin() + path_idx;

						delete curr;
						curr = NULL;
					} else {
						path_iter++;
					}
				} else {
					path_iter++;
				}
			}

			if (tmpBuf != NULL) free(tmpBuf);

			if (!wcardPresent && !forceOverwrite && argc - optind > 1) {
				// more than one file to organize, but there is no wildcard in the pattern
				// every file would overwrite its predecessor
				cout << "How to organize " << argc - optind << " files without at least one wildcard in the pattern? -o is ignored! Use -F to make this nonsense happen" << endl;
				orgPattern = NULL;
				goto finish;
			}

			trim_whitespace(path);
			const char *tmpPath = path->c_str();
			if (strcmp(tmpPath, argv[currIndex]) == 0)
				// source and dest are the same
				continue;

			struct stat f_stats;
			if ((dirname = (char*) malloc(strlen(tmpPath) + 1)) == NULL) {
				cerr << progname << ": Could not allocate needed memory" << endl;
				exit(2);
			}
			strcpy(dirname, tmpPath);
			filename = strrchr(dirname, '/');
			if (filename == NULL) {
				filename = dirname;
				dirname = NULL;
			} else {
				*filename++ = '\0';
			}

			if (dirname != NULL) {
				if (access(dirname, W_OK) != 0) {
					if (errno == ENOENT) {
						if (creat_dir_r(dirname) != 0) {
							goto error;
						}
					} else {
						fprintf(stderr, "%s: %s: ", progname, tmpPath);
						perror(NULL);
						goto error;
					}
				}

				if (stat(dirname, &f_stats) != 0 || !(f_stats.st_mode & S_IFDIR)) {
					cerr << progname << ": Not a directory: " << dirname << endl;
					goto error;
				}
			}

			// move/copy file to new position
			if (stat(tmpPath, &f_stats) == 0) {
				// already exists
				struct stat cf_stats;
				stat(argv[currIndex], &cf_stats);
				if (f_stats.st_ino == cf_stats.st_ino)
					// source and dest are the same
					goto finish;
				if (!(f_stats.st_mode & S_IFREG)) {
					cerr << progname << ": " << tmpPath << ": Not a regular file" << endl;
					goto error;
				} else {
					// overwrite?
					if (access(tmpPath, W_OK) != 0) {
						cerr << progname << ": " <<  tmpPath << ": Permission denied" << endl;
						goto error;
					} else if (!forceOverwrite) {
						// have to ask the user if he wants to overwrite the file
						if (!confirm_overwrite(tmpPath)) {
							goto finish;
						}
					}
				}
			}

			FILE *inFile, *outFile;
			buffer = (char*) malloc(FCPY_BUFSIZE);
			if (buffer == NULL) {
				cerr << progname << ": Could not allocate needed memory" << endl;
				exit(2);
			}
			outFile = fopen(tmpPath, "w+");
			if (outFile == NULL) {
				cerr << progname << ": Could not open for writing: " << tmpPath << endl;
				goto error;
			}
			inFile = fopen(argv[currIndex], "r");
			if (inFile == NULL) {
				cerr << progname << ": Could not open for reading: " << argv[currIndex] << endl;
				goto error;
			}
			// copy content of inFile to outFile
			while (!feof(inFile) && writeOK) {
				fread(buffer, FCPY_BUFSIZE, 1, inFile);
				if (ferror(inFile)) {
					cerr << progname << ": " << argv[currIndex] << ": Read error" << endl;
					writeOK = false;
				} else {
					fwrite(buffer, FCPY_BUFSIZE, 1, outFile);
					if (ferror(outFile)) {
						cerr << progname << ": " << tmpPath << ": Write error" << endl;
						writeOK = false;
					}
				}
			}
			fclose(inFile);
			fclose(outFile);
			if (writeOK) {
				if (orgMove) unlink(argv[currIndex]);
			} else {
				unlink(tmpPath);
				goto error;
			}

			goto finish;

error:
			cerr << "Not organized: " << argv[currIndex] << endl;

finish:
			delete path;
			if (dirname != NULL) free(dirname);
			else if (filename != NULL) free(filename);
			if (buffer != NULL) free(buffer);
		}
	}

	return 0;
}

