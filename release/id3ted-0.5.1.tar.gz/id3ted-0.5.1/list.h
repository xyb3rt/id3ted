/* id3ted
 * list.h - header for list routines
 * Copyright (C) 2008  Bert Muennich (muennich@informatik.hu-berlin.de)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 * USA.
 */

#ifndef __LIST_H__
#define __LIST_H__

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <taglib/tbytevector.h>
#include <taglib/id3v1tag.h>
#include <taglib/id3v1genres.h>
#include <taglib/id3v2tag.h>
#include <taglib/id3v2frame.h>
#include <taglib/id3v2header.h>
#include <taglib/mpegfile.h>
#include <taglib/commentsframe.h>
#include <taglib/attachedpictureframe.h>
#include <taglib/textidentificationframe.h>
#include <taglib/urllinkframe.h>
#include <taglib/unsynchronizedlyricsframe.h>

#include "general.h"
#include "frametable.h"
//#include "misc.h"

using namespace std;
using namespace TagLib;

void printGenreList();
int listTags(TagLib::MPEG::File*, bool);
void showInfo(TagLib::MPEG::File*);

#endif /* __LIST_H__ */
