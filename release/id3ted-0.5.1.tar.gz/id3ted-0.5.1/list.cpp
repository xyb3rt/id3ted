/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *  
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "list.h"

void printGenreList() {
	int i;

	for (i = 0; i < ID3v1::genreList().size(); i++) {
		printf("  %5d: ", i);
		cout << ID3v1::genre(i) << endl;
	}
}

bool printID3v1Tag(TagLib::MPEG::File *mp3File) {
	ID3v1::Tag *ID3v1Tag = mp3File->ID3v1Tag();

	if (!ID3v1Tag || ID3v1Tag->isEmpty()) {
		return false;
	}

	int year = ID3v1Tag->year();
	String genreStr = ID3v1Tag->genre();
	int genreIdx = ID3v1::genreIndex(genreStr);
	
	cout << "ID3v1" << ":" << endl;

	printf("    Title: %-30s  Track: %d\n",
			ID3v1Tag->title().toCString(USE_UNICODE), ID3v1Tag->track());
	
	printf("   Artist: %-30s   Year: %-4s\n",
			ID3v1Tag->artist().toCString(USE_UNICODE), (year != 0 ? String::number(year).toCString() : ""));

	printf("    Album: %-30s  Genre: %s (%d)\n",
			ID3v1Tag->album().toCString(USE_UNICODE), (genreIdx == 255 ? "Unknown" : genreStr.toCString()), genreIdx);

	printf("  Comment: %s\n", ID3v1Tag->comment().toCString(USE_UNICODE));

	return true;
}

bool printID3v2Tag(TagLib::MPEG::File *mp3File, bool withDesc) {
	ID3v2::Tag *ID3v2Tag = mp3File->ID3v2Tag();

	if (!ID3v2Tag || ID3v2Tag->isEmpty()) {
		return false;
	}

	int frameCount = ID3v2Tag->frameList().size(); 

	cout << "ID3v2." << ID3v2Tag->header()->majorVersion() << " (" << frameCount << (frameCount != 1 ? " frames):" : "frame):") << endl;
	
	ID3v2::FrameList::ConstIterator it = ID3v2Tag->frameList().begin();
	for (; it != ID3v2Tag->frameList().end(); it++) {
		cout << "  " << (*it)->frameID().mid(0, 4);
		if (withDesc) cout << " (" << frameDescription((*it)->frameID().data()) << ")";
		cout << ": ";
		
		switch (frameID((*it)->frameID().data())) {
			case FID3_APIC: {
				ID3v2::AttachedPictureFrame *apf = dynamic_cast<ID3v2::AttachedPictureFrame*>(*it);
				if (apf != NULL) {
					int picSize = apf->picture().size();
					char *unit = "bytes";

					if (picSize >= 1073741824) {
						picSize /= 1073741824;
						unit = "GB";
					} else if (picSize >= 1048576) {
						picSize /= 1048576;
						unit = "MB";
					} else if (picSize >= 1024) {
						picSize /= 1024;
						unit = "KB";
					}

					cout << apf->mimeType() << ", " << picSize << " " << unit;
				}
				cout << endl;
				break;
			}
			case FID3_COMM: {
				ID3v2::CommentsFrame *cf = dynamic_cast<ID3v2::CommentsFrame*>(*it);
				if (cf != NULL) cout << "[" << cf->description().toCString(USE_UNICODE) << "](" << cf->language() << "): " << cf->toString().toCString(USE_UNICODE);
				cout << endl;
				break;
			}
			case FID3_TCON: {
				String genreStr = (*it)->toString();
				int genreIdx = 255;
				sscanf(genreStr.toCString(), "(%d)", &genreIdx);

				if (genreIdx == 255) {
					sscanf(genreStr.toCString(), "%d", &genreIdx);
				}
				if (genreIdx != 255) {
					genreStr = ID3v1::genre(genreIdx);
				}

				cout << genreStr << endl;
				break;
			}
			case FID3_USLT: {
				ID3v2::UnsynchronizedLyricsFrame *ulf = dynamic_cast<ID3v2::UnsynchronizedLyricsFrame*>(*it);
				if (ulf != NULL) {
					cout << "[" << ulf->description() << "](" << ulf->language() << "): ";
					const char *lyrics = ulf->text().toCString(USE_UNICODE);
					while (*lyrics != '\0') {
						if (*lyrics == (char) 10 || *lyrics == (char) 13) {
							cout << endl << "    ";
						} else {
							putchar(*lyrics);
						}
						lyrics++;
					}
				}
				cout << endl;
				break;
			}
			case FID3_TXXX: {
				ID3v2::UserTextIdentificationFrame *utif = dynamic_cast<ID3v2::UserTextIdentificationFrame*>(*it);
				if (utif != NULL) {
					StringList textList = utif->fieldList();
					cout << "[" << utif->description() << "]: ";
					if (textList.size() >= 2) cout << textList[1].toCString(USE_UNICODE);
				}
				cout << endl;
				break;
			}
			case FID3_WXXX: {
				ID3v2::UserUrlLinkFrame *uulf = dynamic_cast<ID3v2::UserUrlLinkFrame*>(*it);
				if (uulf != NULL) cout << "[" << uulf->description() << "]: " << uulf->url().toCString(USE_UNICODE);
				cout << endl;
				break;
			}
			case FID3_XXXX: {
				cout << endl;
				break;
			}
			default: {
				cout << (*it)->toString().toCString(USE_UNICODE) << endl;
				break;
			}
		}
	}
	
	return true;
}

int listTags(TagLib::MPEG::File *file, bool withDesc) {
	int returnCode = 0;

	if (printID3v1Tag(file)) {
		returnCode |= 1;
	}

	if (printID3v2Tag(file, withDesc)) {
		returnCode |= 2;
	}

	if (returnCode == 0) {
		cout << "No id3 tag found!" << endl;
	}
	
	return returnCode;
}

void showInfo(TagLib::MPEG::File *file) {
	MPEG::Properties *properties = file->audioProperties();
	
	if (!properties) return;

	char* version;
	switch (properties->version()) {
		case 1: {
			version = "2";
			break;
		}
		case 2: {
			version = "2.5";
			break;
		}
		default: {
			version = "1";
			break;
		}
	}

	char *channelMode;
	switch (properties->channelMode()) {
		case 0: {
			channelMode = "Stereo";
			break;
		}
		case 1: {
			channelMode = "JointStereo";
			break;
		}
		case 2: {
			channelMode = "DualChannel";
			break;
		}
		default: {
			channelMode = "SingleChannel";
			break;
		}
	}

	cout << "MPEG " << version << " Layer " << properties->layer() << " " << channelMode << endl;

	int length = properties->length();
	printf("bitrate: %d kBit/s, sample rate: %d Hz, length: %02d:%02d:%02d\n",
			properties->bitrate(), properties->sampleRate(),
			length / 3600, length / 60, length % 60);
}
