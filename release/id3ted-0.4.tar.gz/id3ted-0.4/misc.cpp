/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *  
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "misc.h"

const char* basename(const char *string) {
	const char *res = strrchr(string, '/');
	if (res == NULL) return string;
	return ++res;
}

void printVersion(const char *sName) {
	size_t nIndex;
	cout << sName << " - command line id3 tag editor" << endl;
	cout << "version " << VERSION << endl;
	cout << "Written by Bert Muennich" << endl;
	cout << "Uses TagLib, written by Scott Wheeler" << endl;
}

void printUsage(const char *sName) {
	cout << "Usage: " << sName << " [OPTIONS]... FILES" << endl << endl;
	cout << "OPTIONS:" << endl;
	cout << "If a long option shows an argument as mandatory," << endl;
	cout << "then it is also mandatory for the equivalent short option." << endl << endl;
	cout << "  -h, --help             display this help and exit" << endl;
	cout << "  -f, --list-frames      display all possible frames for id3v2" << endl;
	cout << "  -G, --list-genres      list all id3v1 genres" << endl;
	cout << "  -v, --version          display version information and exit" << endl;
	cout << "  -i, --info             display general information for the file(s)" << endl;
	cout << "  -l, --list             list the tag(s) on the file(s)" << endl;
	cout << "  -L, --list-wd          same as -l, but list id3v2 frames with description" << endl;
	cout << "  -s, --strip-v1         strip id3v1 tag" << endl;
	cout << "  -S, --strip-v2         strip id3v2 tag" << endl;
	cout << "  -D, --delete-all       delete both id3v1 and id3v2 tag" << endl;
	cout << "  -1, --id3v1-only       write only id3v1 tag" << endl;
	cout << "  -2, --id3v2-only       write only id3v2 tag" << endl;
	cout << "  -3, --write-all        write both id3v1 and id3v2 tag" << endl;
	cout << "  -x, --extract-apics    extract all attached pictures" << endl;
	cout << "  -d, --delimiter C      set the delimiter for multiple field option" << endl
	<< "                         arguments to the given character (default is '" << FIELD_DELIM << "')" << endl;
	cout << "  -r, --remove FID       remove all frames with the given frame id" << endl;
	cout << "  -a, --artist ARTIST    set the artist information" << endl;
	cout << "  -A, --album ALBUM      set the album title information" << endl;
	cout << "  -t, --title SONG       set the song title information" << endl;
	cout << "  -c, --comment COMMENT[" << FIELD_DELIM << "DESCRIPTION[" << FIELD_DELIM << "LANGUAGE]]"
	<< endl << "                         set the comment information (both"
	<< endl << "                         description and language optional)" << endl;    
	cout << "  -g, --genre NUM        set the genre number" << endl;
	cout << "  -T, --track NUM[/NUM]  set the track number/optional: total # of tracks" << endl;
	cout << "  -y, --year NUM         set the year" << endl;
	cout << endl;
	cout << "You can set the value of many id3v2 frames by using \"--FID\"" << endl;
	cout << "For example: " << endl;
	cout << "    " << sName << " --TALB \"Sjofn\" file.mp3" << endl;
	cout << "would set the \"Album/Movie/Show title\" frame to \"Sjofn\"." << endl;
	cout << "Use `" << sName << " -f' to get a list of supported frames (marked with *)." << endl;
	cout << "There are some frames with multiple fields:" << endl;
	cout << "    --COMM COMMENT[" << FIELD_DELIM << "DESCRIPTION[" << FIELD_DELIM << "LANGUAGE]]" << endl;
	cout << "    --TXXX TEXT[" << FIELD_DELIM << "DESCRIPTION]" << endl;
	cout << "    --WXXX URL[" << FIELD_DELIM << "DESCRIPTION]" << endl;
	cout << "Only the first field is mandatory, the others are optional." << endl;
	cout << "When using --APIC the argument has to be a file!" << endl;
	cout << endl;
	cout << "When using -i or --extract-apics all attached pictures are saved as" << endl;
	cout << "MP3FILENAME.apic-NUM.FORMAT in the same directory as the mp3 file." << endl;
}

const char* getMimeType(const char *file) {
	struct magic_set *magic;
	if ((magic = magic_open(MAGIC_MIME|MAGIC_CHECK)) == NULL) return NULL;
	if (magic_load(magic, NULL) != 0) return NULL;
	
	return magic_file(magic, file);
}

