/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *  
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "id3ted.h"

#define MAXNOFRAMES 200
#define TMPSIZE 255

int main(int argc, char **argv) {
	int updFlag = 3;
	bool updFlagCheck = false;

	int frameModCounter = 0, frameDelCounter = 0, versionToStrip = 0;
	int argCounter = 0, ii, iOpt, optionIndex;
	char tmp[TMPSIZE], fdelim = FIELD_DELIM;
	bool extractAPICs = false, prevRegOutput = true, listV2WithDesc = false;
	bool haveToWriteFile = false, haveToListTags = false, haveToShowInfo = false;
	FILE *fp;

	char* framesToDel[MAXNOFRAMES];
	struct frameInfo {
		const char *id;
		enum ID3_FrameID fid;
		const char *data;
		ByteVector *dataExt;
	} framesToMod[MAXNOFRAMES];

	while (true) {
		optionIndex = 0;
		iLongOpt = 0;
		optFrameID = FID3_XXXX;

		iOpt = getopt_long(argc, argv, "hfGvilLsSD123xd:r:a:A:t:c:g:y:T:", long_options, &optionIndex);

		if (iOpt == -1 && argCounter == 0) {
			cout << basename(argv[0]) << ": missing arguments" << endl;
			cout << "Try `" << basename(argv[0]) << " --help' for more information" << endl;
			exit(0);
		} else if (iOpt == -1) {
			break;
		}
		if (iOpt == 0) {
			iOpt = iLongOpt;
		}
		argCounter++;

		switch (iOpt) {
			case 0: {
				framesToMod[frameModCounter].id = textFrameID((ID3_FrameID) optFrameID);
				framesToMod[frameModCounter].fid = (enum ID3_FrameID) optFrameID;
				framesToMod[frameModCounter++].data = optarg;
				haveToWriteFile = true;
				break;
			}
			case '?':
			case ':': {
				cout << "Try `" << basename(argv[0]) << " --help' for more information" << endl;
				exit(1);
			}
			case 'h': {
				printUsage(basename(argv[0]));
				exit(0);
			}
			case 'f': {
				printFrameHelp();
				exit(0);
			}
			case 'G': {
				printGenreList();
				exit(0);
			}
			case 'v': {
				printVersion(basename(argv[0]));
				exit(0);
			}
			case 'i': {
				haveToShowInfo = true;
				break;
			}
			case 'l': {
				haveToListTags = true;
				break;
			}
			case 'L': {
				haveToListTags = true;
				listV2WithDesc = true;
				break;
			}
			case 's': {
				versionToStrip |= 1;
				haveToWriteFile = true;
				break;
			}
			case 'S': {
				versionToStrip |= 2;
				haveToWriteFile = true;
				break;
			}
			case 'D': {
				versionToStrip = 3;
				haveToWriteFile = true;
				break;
			}
			// which version of tag should be changed
			case '1': {
				updFlag = 1;
				updFlagCheck = true;
				haveToWriteFile = true;
				break;
			}
			case '2': {
				updFlag = 2;
				updFlagCheck = true;
				haveToWriteFile = true;
				break;
			}
			case '3': {
				updFlag = 3;
				updFlagCheck = true;
				haveToWriteFile = true;
				break;
			}
			// Tagging stuff
			case 'x': {
				extractAPICs = true;
				break;
			}
			case 'd': {
				if (strlen(optarg) == 1) {
					fdelim = optarg[0];
				} else {
					cout << "The argument of -d/--delimiter has to be a single character!" << endl
					<< "Try '" << basename(argv[0]) << " --help' for more information" << endl;
					exit(2);
				}
				break;
			}
			case 'r': {
				framesToDel[frameDelCounter++] = optarg;
				haveToWriteFile = true;
				break;
			}
			case 'a': {
				framesToMod[frameModCounter].id = "TPE1";
				framesToMod[frameModCounter].fid = FID3_TPE1;
				framesToMod[frameModCounter++].data = optarg;
				haveToWriteFile = true;
				break;
			}
			case 'A': {
				framesToMod[frameModCounter].id = "TALB";
				framesToMod[frameModCounter].fid = FID3_TALB;
				framesToMod[frameModCounter++].data = optarg;
				haveToWriteFile = true;
				break;
			}
			case 't': {
				framesToMod[frameModCounter].id = "TIT2";
				framesToMod[frameModCounter].fid = FID3_TIT2;
				framesToMod[frameModCounter++].data = optarg;
				haveToWriteFile = true;
				break;
			}
			case 'c': {
				framesToMod[frameModCounter].id = "COMM";
				framesToMod[frameModCounter].fid = FID3_COMM;
				framesToMod[frameModCounter++].data = optarg;
				haveToWriteFile = true;
				break;
			}
			case 'g': {
				framesToMod[frameModCounter].id = "TCON";
				framesToMod[frameModCounter].fid = FID3_TCON;
				framesToMod[frameModCounter++].data = optarg;
				haveToWriteFile = true;
				break;
			}
			case 'T': {
				framesToMod[frameModCounter].id = "TRCK";
				framesToMod[frameModCounter].fid = FID3_TRCK;
				framesToMod[frameModCounter++].data = optarg;
				haveToWriteFile = true;
				break;
			}
			case 'y': {
				framesToMod[frameModCounter].id = "TYER";
				framesToMod[frameModCounter].fid = FID3_TYER;
				framesToMod[frameModCounter++].data = optarg;
				haveToWriteFile = true;
				break;
			}
			default: {
				cerr << "This isn't supposed to happen!" << endl;
				exit(1);
			}
		}
	}
	
	if (optind == argc) {
		cerr << "No file to work on!" << endl;
		exit(1);
	}

	for (int currIndex = optind; (unsigned int) currIndex < argc; currIndex++) {
		bool hasChanged = false;

		if (!TagLib::File::isReadable(argv[currIndex])) {
			cout << basename(argv[0]) << ": " << argv[currIndex] << ": Could not open file for reading" << endl;
			if (haveToListTags || haveToShowInfo) prevRegOutput = false;
			continue;
		}
		if (haveToWriteFile && !TagLib::File::isWritable(argv[currIndex])) {
			cout << basename(argv[0]) << ": " << argv[currIndex] << ": Could not open file for writing" << endl;
			if (haveToListTags || haveToShowInfo) prevRegOutput = false;
			continue;
		}

		MPEG::File mp3File(argv[currIndex]);
		ID3v1::Tag *ID3v1Tag = mp3File.ID3v1Tag();
		ID3v2::Tag *ID3v2Tag = mp3File.ID3v2Tag(true);
		Tag *ID3Tag = mp3File.tag();

		bool hasID3v1Tag = (ID3v1Tag && !ID3v1Tag->isEmpty());
		if (!updFlagCheck) {
			// if -1, -2 or -3 options are not given on command line,
			// and file has only v1 or v2 tag, update only this
			updFlag = 3;
			if (!hasID3v1Tag) {
				updFlag = 2;
			} else if (!ID3v2Tag || ID3v2Tag->isEmpty()) {
				updFlag = 1;
			}
		}
			
		//extract APICs
		if (extractAPICs) {
			int picNum = 0, infnlen = strlen(argv[currIndex]);
			char *outftype, *outfile = NULL;
			const char *mimetype;
			
			ID3v2::FrameList apicList = ID3v2Tag->frameListMap()["APIC"];
			ID3v2::FrameList::ConstIterator it = apicList.begin();
			for (; it != apicList.end() && picNum <= 20; it++) {
				picNum++;
				ID3v2::AttachedPictureFrame *apf = dynamic_cast<ID3v2::AttachedPictureFrame*>(*it);
				if (apf == NULL) continue;
				mimetype = apf->mimeType().toCString();
				outftype = strrchr(mimetype, '/');
				if (outftype != NULL) {
					outftype++;
				} else {
					outftype = "bin";
				}

				if (picNum < 2) {
					if ((outfile = (char*) malloc(infnlen + 14)) == NULL) {
						cout << "could not allocate needed memory" << endl;
						exit(2);
					}
					strcpy(outfile, argv[currIndex]);
					strcat(outfile, ".apic-");
					sprintf(outfile + infnlen + 6, "%02d", picNum);
					strcat(outfile, ".");
					strcat(outfile, outftype);
				} else {
					sprintf(outfile + infnlen + 6, "%02d", picNum);
					outfile[infnlen + 8] = '.';
					strcpy(outfile + infnlen + 9, outftype);
				}

				if ((fp = fopen(outfile, "w+")) == NULL) continue;
				ByteVector picData = apf->picture();
				unsigned int dataLen = picData.size();
				fwrite(picData.data(), dataLen, 1, fp);
				fclose(fp);
			}
			if (outfile != NULL) free(outfile);
		} // extract APICs

		// delete frames with given fids
		if (frameDelCounter > 0) hasChanged = true;
		for (ii = 0; ii < frameDelCounter; ii++) {
			ID3_FrameID FID = frameID(framesToDel[ii]);
			
			switch (FID) {
				case FID3_TALB: {
					ID3Tag->setAlbum("");
					break;
				}
				case FID3_TCON: {
					ID3Tag->setGenre("");
					break;
				}
				case FID3_TIT2: {
					ID3Tag->setTitle("");
					break;
				}
				case FID3_TPE1: {
					ID3Tag->setArtist("");
					break;
				}
				case FID3_TRCK: {
					ID3Tag->setTrack(0);
					break;
				}
				case FID3_TDRC:
				case FID3_TYER: {
					ID3Tag->setYear(0);
					break;
				}
				case FID3_COMM: {
					ID3v1Tag->setComment("");
				}
				default: {
					ID3v2Tag->removeFrames(framesToDel[ii]);
					break;
				}
			}
		}

		// loop through the frames for adding/modifying
		if (frameModCounter > 0) hasChanged = true;
		for (ii = 0; ii < frameModCounter; ii++) {
			bool TypeOne = false;
			ID3v2::FrameList oldList = ID3v2Tag->frameListMap()[framesToMod[ii].id];

			switch (framesToMod[ii].fid) {
				case FID3_APIC: {
					if (currIndex == optind) {
						const char *mimetype;
						FILE *fptr;

						fptr = fopen(framesToMod[ii].data, "r");
						if (fptr == NULL) {
							fprintf(stderr, "%s: %s: ", basename(argv[0]), framesToMod[ii].data);
							perror(NULL);
							framesToMod[ii].fid = FID3_XXXX;
							break;
						}
					
						mimetype = getMimeType(framesToMod[ii].data);
						char *mttemp = strstr(mimetype, "image");
						if (mttemp == NULL) {
							cout << basename(argv[0]) << ": " << framesToMod[ii].data << ": wrong mime-type: " << mimetype << "! Not an image, not attached.\n";
							framesToMod[ii].fid = FID3_XXXX;
							break;
						}
					
						fseek(fptr, 0, SEEK_END);
						size_t fileSize = ftell(fptr);
						fseek(fptr, 0, SEEK_SET);
						char* picFile = new char[fileSize];
						if (picFile != NULL) {
							fread(picFile, 1, fileSize, fptr);
							framesToMod[ii].dataExt = new ByteVector(picFile, fileSize);
							framesToMod[ii].data = mimetype;
							delete [] picFile;
						} else {
							framesToMod[ii].fid = FID3_XXXX;
							break;
						}
						fclose(fptr);
					}

					ID3v2::AttachedPictureFrame *apf = new ID3v2::AttachedPictureFrame();
					apf->setMimeType(framesToMod[ii].data);
					apf->setType((ID3v2::AttachedPictureFrame::Type) 3);
					apf->setPicture(*(framesToMod[ii].dataExt));
					ID3v2Tag->addFrame(apf);

					break;
				}
				case FID3_TALB: {
					ID3Tag->setAlbum(framesToMod[ii].data);
					break;
				}
				case FID3_PCNT:
				case FID3_RBUF:
				case FID3_TBPM:
				case FID3_TCOM:
				case FID3_TCOP:
				case FID3_TDEN:
				case FID3_TDLY:
				case FID3_TDOR:
				case FID3_TDRL:
				case FID3_TDTG:
				case FID3_TENC:
				case FID3_TEXT:
				case FID3_TFLT:
				case FID3_TIT1:
				case FID3_TIT3:
				case FID3_TKEY:
				case FID3_TLAN:
				case FID3_TLEN:
				case FID3_TMCL:
				case FID3_TMED:
				case FID3_TMOO:
				case FID3_TOAL:
				case FID3_TOFN:
				case FID3_TOLY:
				case FID3_TOPE:
				case FID3_TOWN:
				case FID3_TPE2:
				case FID3_TPE3:
				case FID3_TPE4:
				case FID3_TPOS:
				case FID3_TPRO:
				case FID3_TPUB:
				case FID3_TRSN:
				case FID3_TRSO:
				case FID3_TSOA:
				case FID3_TSOP:
				case FID3_TSOT:
				case FID3_TSRC:
				case FID3_TSSE:
				case FID3_TSST:
				case FID3_USER: {
					if (strlen(framesToMod[ii].data) > 0) {
						if (!oldList.isEmpty()) {
							oldList.front()->setText(framesToMod[ii].data);
						} else {
							ID3v2::TextIdentificationFrame *tf = new ID3v2::TextIdentificationFrame(framesToMod[ii].id);
							tf->setText(framesToMod[ii].data);
							ID3v2Tag->addFrame(tf);
						}
					} else if (!oldList.isEmpty()) {
						ID3v2Tag->removeFrame(oldList.front());
					}

					break;
				}
				case FID3_USLT: {
					TypeOne = true;
				}
				case FID3_COMM: {
					bool setV1Comm = false;
					String input(framesToMod[ii].data);
					String text, description, language;
					int inputLength = input.size();
					int textLength = inputLength, descriptionLength = 0;
					int descriptionIdx = 0, languageIdx = 0;

					descriptionIdx = input.find(fdelim, 0);
					if (descriptionIdx != -1) {
						textLength = descriptionIdx++;
						descriptionLength = inputLength - descriptionIdx;
						languageIdx = input.find(fdelim, descriptionIdx);
						if (languageIdx != -1) {
							descriptionLength = languageIdx++ - descriptionIdx;
							language = input.substr(languageIdx, inputLength - languageIdx).stripWhiteSpace();
						}
						description = input.substr(descriptionIdx, descriptionLength);
					}
					text = input.substr(0, textLength);
					if (descriptionIdx <= 0 && !TypeOne) setV1Comm = (updFlag & 1)  || hasID3v1Tag;
					if (language.size() != 3) language = "XXX";

					bool alreadyIn = false;
					ID3v2::CommentsFrame *cf;
					ID3v2::UnsynchronizedLyricsFrame *ulf;

					ID3v2::FrameList::ConstIterator it = oldList.begin();
					while (it != oldList.end()) {
						if (TypeOne) {
							if ((ulf = dynamic_cast<ID3v2::UnsynchronizedLyricsFrame*>(*it)) == NULL) continue;
							if (ulf->language() == "" || ulf->language().isEmpty() || ulf->language().toUInt() == 0) {
								ulf->setLanguage("XXX");
							}
							alreadyIn = description == ulf->description() && language == ulf->language();
						} else {	
							if ((cf = dynamic_cast<ID3v2::CommentsFrame*>(*it)) == NULL) continue;
							if (cf->language() == "" || cf->language().isEmpty() || cf->language().toUInt() == 0) {
								cf->setLanguage("XXX");
							}
							alreadyIn = description == cf->description() && language == cf->language();
						}

						if (alreadyIn) {
							if (textLength > 0) {
								(*it)->setText(text);
							} else {
								ID3v2Tag->removeFrame(*it);
							}
							break;
						}
						it++;
					}

					if (setV1Comm) {
						ID3v1Tag->setComment(text);
					}

					if (!alreadyIn && textLength > 0) {
						if (TypeOne) {
							ulf = new ID3v2::UnsynchronizedLyricsFrame((enum TagLib::String::Type) 0);
							ulf->setText(text);
							if (descriptionLength > 0) ulf->setDescription(description);
							ulf->setLanguage(language.toCString());
							ID3v2Tag->addFrame(ulf);
						} else {
							cf = new ID3v2::CommentsFrame((enum TagLib::String::Type) 0);
							cf->setText(text);
							if (descriptionLength > 0) cf->setDescription(description);
							cf->setLanguage(language.toCString());
							ID3v2Tag->addFrame(cf);
						} 
					}

					break;
				}
				case FID3_TCON: {
					ID3Tag->setGenre(framesToMod[ii].data);
					break;
				}
				case FID3_TIT2: {
					ID3Tag->setTitle(framesToMod[ii].data);
					break;
				}
				case FID3_TPE1: {
					ID3Tag->setArtist(framesToMod[ii].data);
					break;
				}
				case FID3_TRCK: {
					ID3v1Tag->setTrack(0);
					if (strlen(framesToMod[ii].data) > 0) {
						if (!oldList.isEmpty()) {
							oldList.front()->setText(framesToMod[ii].data);
						} else {
							ID3v2::TextIdentificationFrame *tif = new ID3v2::TextIdentificationFrame(framesToMod[ii].id);
							tif->setText(framesToMod[ii].data);
							ID3v2Tag->addFrame(tif);
						}
					} else if (!oldList.isEmpty()) {
						ID3v2Tag->removeFrame(oldList.front());
					}
					
					break;
				}
				case FID3_TDRC:
				case FID3_TYER: {
					ID3Tag->setYear(atoi(framesToMod[ii].data));
					break;
				}
				case FID3_WCOM:
				case FID3_WCOP:
				case FID3_WOAF:
				case FID3_WOAR:
				case FID3_WOAS:
				case FID3_WORS:
				case FID3_WPAY:
				case FID3_WPUB: {
					if (strlen(framesToMod[ii].data) > 0) {
						if (!oldList.isEmpty()) {
							oldList.front()->setText(framesToMod[ii].data);
						} else {
							ID3v2::UrlLinkFrame *ulf = new ID3v2::UrlLinkFrame(framesToMod[ii].id);
							ulf->setUrl(framesToMod[ii].data);
							ID3v2Tag->addFrame(ulf);
						}
					} else if (!oldList.isEmpty()) {
						ID3v2Tag->removeFrame(oldList.front());
					}

					break;
				}
				case FID3_TXXX: {
					TypeOne = true;
				}
				case FID3_WXXX: {
					String input(framesToMod[ii].data);
					String description;
					int inputLength = input.size();
					int textLength = inputLength, descriptionLength = 0;
					int descriptionIdx = 0;

					descriptionIdx = input.find(fdelim, 0);
					if (descriptionIdx != -1) {
						textLength = descriptionIdx++;
						descriptionLength = inputLength - descriptionIdx;
						description = input.substr(descriptionIdx, descriptionLength);
					} else if (TypeOne) {
						description = input.substr(0, textLength);
					}

					bool alreadyIn = false;
					ID3v2::UserUrlLinkFrame *uulf;
					ID3v2::UserTextIdentificationFrame *utif;

					ID3v2::FrameList::ConstIterator it = oldList.begin();
					while (it != oldList.end()) {
						if (TypeOne) {
							if ((utif = dynamic_cast<ID3v2::UserTextIdentificationFrame*>(*it)) == NULL) continue;
							alreadyIn = description == utif->description();
						} else {
							if ((uulf = dynamic_cast<ID3v2::UserUrlLinkFrame*>(*it)) == NULL) continue;
							alreadyIn = description == uulf->description();
						}
						if (alreadyIn) {
							if (textLength > 0) {
								(*it)->setText(input.substr(0, textLength));
							} else {
								ID3v2Tag->removeFrame(*it);
							}
							break;
						}
						it++;
					}
					
					if (!alreadyIn && textLength > 0) {
						if (TypeOne) {
							utif = new ID3v2::UserTextIdentificationFrame((enum TagLib::String::Type) 0);
							if (descriptionLength > 0) utif->setDescription(description);
							utif->setText(input.substr(0, textLength));
							ID3v2Tag->addFrame(utif);
						} else {
							uulf = new ID3v2::UserUrlLinkFrame((enum TagLib::String::Type) 0);
							if (descriptionLength > 0) uulf->setDescription(description);
							uulf->setUrl(input.substr(0, textLength));
							ID3v2Tag->addFrame(uulf);
						}
					}

					break;
				}
			}
		}

		// save the specified tags to the file
		if (hasChanged || updFlagCheck) {
			// bug in TagLib?: deleting last frame in id3v2 tag somewhere in the code above
			// and then saving file here causes the recovery of this last deleted frame. 
			// solution: strip the whole tag if it is empty before writing file!
			if ((updFlag & 2) && ID3v2Tag->isEmpty()) mp3File.strip(2);
			mp3File.save(updFlag, false);
		}

		// delete whole tag version
		if (versionToStrip > 0) {
			if (!mp3File.strip(versionToStrip)) {
				cout << "could not delete id3 tag from file \"" << argv[currIndex] << "\"" << endl;
			}
		}

		if (haveToShowInfo || haveToListTags) {
			cout << argv[currIndex] << ":" << endl;
		}

		if (haveToShowInfo) {
			showInfo(&mp3File);
		}

		if (haveToListTags) {
			listTags(&mp3File, listV2WithDesc);
		}

		if ((haveToShowInfo || haveToListTags) && currIndex < argc - 1) {
			cout << endl;
		}
	}

	return 0;
}

