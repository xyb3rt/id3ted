/* id3ted
 * list.h - header for list routines
 * Copyright (C) 2008  Bert Muennich (muennich@informatik.hu-berlin.de)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 * USA.
 */

#ifndef __MISC_H__
#define __MISC_H__
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <string.h>
#include <magic.h>

#define FIELD_DELIM ':'

using namespace std;

const char* basename(const char*);
void printVersion(const char*);
void printUsage(const char*);
const char* getMimeType(const char*);

#endif /* __MISC_H__ */
