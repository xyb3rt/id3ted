#include <cstdio>
#include <iostream>
#include <id3/tag.h>
#include <cstdlib>

#include "convert.h"

char* basename(char *string) {
	char *res = strrchr(string, '/');
	if (res == NULL) return string;
	return ++res;
}

struct strNframe {
	char *str;
	ID3_FrameID id; };
	
struct strNframe frame_table[] = {
	{ "AENC", ID3FID_AUDIOCRYPTO },
	{ "APIC", ID3FID_PICTURE },
	{ "COMM", ID3FID_COMMENT },
	{ "ENCR", ID3FID_CRYPTOREG },
	{ "EQUA", ID3FID_EQUALIZATION },
	{ "ETCO", ID3FID_EVENTTIMING },
	{ "GEOB", ID3FID_GENERALOBJECT },
	{ "GRID", ID3FID_GROUPINGREG },
	{ "IPLS", ID3FID_INVOLVEDPEOPLE },
	{ "LINK", ID3FID_LINKEDINFO },
	{ "MCDI", ID3FID_CDID },
	{ "MLLT", ID3FID_MPEGLOOKUP },
	{ "OWNE", ID3FID_OWNERSHIP },
	{ "PRIV", ID3FID_PRIVATE },
	{ "PCNT", ID3FID_PLAYCOUNTER },
	{ "POPM", ID3FID_POPULARIMETER },
	{ "POSS", ID3FID_POSITIONSYNC },
	{ "RBUF", ID3FID_BUFFERSIZE },
	{ "RVAD", ID3FID_VOLUMEADJ },
	{ "RVRB", ID3FID_REVERB },
	{ "SYLT", ID3FID_SYNCEDLYRICS },
	{ "SYTC", ID3FID_SYNCEDTEMPO },
	{ "TALB", ID3FID_ALBUM },
	{ "TBPM", ID3FID_BPM },
	{ "TCOM", ID3FID_COMPOSER },
	{ "TCON", ID3FID_CONTENTTYPE },
	{ "TCOP", ID3FID_COPYRIGHT },
	{ "TDAT", ID3FID_DATE },
	{ "TDLY", ID3FID_PLAYLISTDELAY },
	{ "TENC", ID3FID_ENCODEDBY },
	{ "TEXT", ID3FID_LYRICIST },
	{ "TFLT", ID3FID_FILETYPE },
	{ "TIME", ID3FID_TIME },
	{ "TIT1", ID3FID_CONTENTGROUP },
	{ "TIT2", ID3FID_TITLE },
	{ "TIT3", ID3FID_SUBTITLE },
	{ "TKEY", ID3FID_INITIALKEY },
	{ "TLAN", ID3FID_LANGUAGE },
	{ "TLEN", ID3FID_SONGLEN },
	{ "TMED", ID3FID_MEDIATYPE },
	{ "TOAL", ID3FID_ORIGALBUM },
	{ "TOFN", ID3FID_ORIGFILENAME },
	{ "TOLY", ID3FID_ORIGLYRICIST },
	{ "TOPE", ID3FID_ORIGARTIST },
	{ "TORY", ID3FID_ORIGYEAR },
	{ "TOWN", ID3FID_FILEOWNER },
	{ "TPE1", ID3FID_LEADARTIST },
	{ "TPE2", ID3FID_BAND },
	{ "TPE3", ID3FID_CONDUCTOR },
	{ "TPE4", ID3FID_MIXARTIST },
	{ "TPOS", ID3FID_PARTINSET },
	{ "TPUB", ID3FID_PUBLISHER },
	{ "TRCK", ID3FID_TRACKNUM },
	{ "TRDA", ID3FID_RECORDINGDATES },
	{ "TRSN", ID3FID_NETRADIOSTATION },
	{ "TRSO", ID3FID_NETRADIOOWNER },
	{ "TSIZ", ID3FID_SIZE },
	{ "TSRC", ID3FID_ISRC },
	{ "TSSE", ID3FID_ENCODERSETTINGS },
	{ "TXXX", ID3FID_USERTEXT },
	{ "TYER", ID3FID_YEAR },
	{ "UFID", ID3FID_UNIQUEFILEID },
	{ "USER", ID3FID_TERMSOFUSE },
	{ "USLT", ID3FID_UNSYNCEDLYRICS },
	{ "WCOM", ID3FID_WWWCOMMERCIALINFO },
	{ "WCOP", ID3FID_WWWCOPYRIGHT },
	{ "WOAF", ID3FID_WWWAUDIOFILE },
	{ "WOAR", ID3FID_WWWARTIST },
	{ "WOAS", ID3FID_WWWAUDIOSOURCE },
	{ "WORS", ID3FID_WWWRADIOPAGE },
	{ "WPAY", ID3FID_WWWPAYMENT },
	{ "WPUB", ID3FID_WWWPUBLISHER },
	{ "WXXX", ID3FID_WWWUSER } };

int GetFrameTableCount() {
	return sizeof(frame_table) / (sizeof(char*) + sizeof(ID3_FrameID));
}

void DeleteTag(int argc, char *argv[], int optind, int whichTags) {
    FILE * fp;
    
    for (size_t nIndex = optind; nIndex < argc; nIndex++)
    {
      /* cludgy to check if we have the proper perms */
      fp = fopen(argv[nIndex], "r+");
      if (fp == NULL) { /* file didn't open */
        fprintf(stderr, "%s: %s: ", basename(argv[0]), argv[nIndex]);
        perror(NULL);
        continue;
      }
      fclose(fp);

      ID3_Tag myTag;

      std::cout << "Stripping id3 tag in \"";
      std::cout << argv[nIndex] << "\"...";

      myTag.Clear();
      myTag.Link(argv[nIndex], ID3TT_ALL);

      luint nTags;
      switch(whichTags) 
      {
        case 1: 
          nTags = myTag.Strip(ID3TT_ID3V1);
          std::cout << "id3v1 ";
          break;
        case 2:
          nTags = myTag.Strip(ID3TT_ID3V2);
          std::cout << "id3v2 ";
          break; 
        case 0:
        default:
          nTags = myTag.Strip(ID3TT_ID3);
          std::cout << "id3v1 and v2 ";
      }

      std::cout << "stripped." << std::endl;
    }

  return;
}


void ConvertTag(int argc, char *argv[], int optind)
{
    for (size_t nIndex = optind; nIndex < argc; nIndex++)
    {
      ID3_Tag myTag;

      std::cout << "Converting id3v1 tag to id3v2 in ";
      std::cout << argv[nIndex] << "...";

      myTag.Clear();
      myTag.Link(argv[nIndex], ID3TT_ALL);

      luint nTags;

      nTags = myTag.Update(ID3TT_ID3V2);
      std::cout << " converted ";
      std::cout << std::endl;
    }

  return;
}

ID3_FrameID ConvertStr2FID(char *string) {
	int a = 0;
    int b = GetFrameTableCount() - 1;
    int i, cmp;

    while(a <= b) {
        i = (a + b) / 2;
        char* cmpwith = frame_table[i].str;
        cmp = strcmp(cmpwith, string);

        if (cmp == 0) {
            return frame_table[i].id;
        } else if (cmp < 0) {
            a = i + 1;
        } else {
            b = i - 1;
		}
    }

    return ID3FID_NOFRAME;
}