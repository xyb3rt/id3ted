#include <cstdio>
#include <cstdlib>
#include <id3/tag.h>

#include "frametable.h"
#include "misc.h"

using namespace std;

char* basename(char *string) {
	char *res = strrchr(string, '/');
	if (res == NULL) return string;
	return ++res;
}

ID3_TagType TagDelete(char *filename, ID3_TagType whichTags) {
	ID3_Tag tag;
	ID3_TagType typeDeleted;
	
	tag.Link(filename, ID3TT_ID3);
	typeDeleted = (ID3_TagType) tag.Strip(whichTags);
	tag.Clear();
	
	return typeDeleted;
}

ID3_FrameID ConvertFName2FID(const char *fname) {
	int a = 0;
	int b = frameTableCount;
	int i, cmp;
	
	while(a <= b) {
		i = (a + b) / 2;
		char *cmpwith = frameTable[i].name;
		cmp = strcmp(cmpwith, fname);
		
		if (cmp == 0) {
			return frameTable[i].fid;
		} else if (cmp < 0) {
			a = i + 1;
		} else {
			b = i - 1;
		}
	}
	
	return ID3FID_NOFRAME;
}

char* ConvertFID2FDesc(ID3_FrameID frame_id) {
	int a = 0;
	int b = frameTableCount;
	int i, cmp;
	
	while(a <= b) {
		i = (a + b) / 2;
		ID3_FrameID cmpwith = frameTable[i].fid;
		
		if (cmpwith == frame_id) {
			return frameTable[i].desc;
		} else if (cmpwith < frame_id) {
			a = i + 1;
		} else {
			b = i - 1;
		}
	}
	
	return "";
}

const char* getMimeType(char *file) {
	struct magic_set *magic;
	if ((magic = magic_open(MAGIC_MIME|MAGIC_CHECK)) == NULL) return NULL;
	if (magic_load(magic, NULL) != 0) return NULL;
	
	return magic_file(magic, file);
}

