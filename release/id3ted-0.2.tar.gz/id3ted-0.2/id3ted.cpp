#if defined HAVE_CONFIG_H
#include <config.h>
#endif

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <cstring>
#include <id3/tag.h>
#include <getopt.h>
#include <id3/misc_support.h>

#include <sys/types.h>
#include <sys/stat.h>

#include "genre.h"
#include "convert.h"
#include "frametable.h"

#define MAXNOFRAMES 1000
#define TMPSIZE 255
#define FIELD_DELIM ':'

// BOOLEAN
#define BOOL int
#define TRUE 1
#define FALSE 0

using namespace std;

// Write both tags by default
flags_t UpdFlags = ID3TT_ALL;
BOOL UpdFlagsCheck = FALSE;

void PrintVersion(char *sName) {
	size_t nIndex;
	cout << sName << " - command line id3 tag editor, version " << VERSION << endl;
	cout << "Uses " << ID3LIB_FULL_NAME << endl;
	cout << "Written by Bert Muennich" << endl;
}

void PrintUsage(char *sName) {
	cout << sName << " - command line id3 tag editor, version " << VERSION << endl << endl;
	cout << "Usage: " << sName << " [OPTIONS]... FILES" << endl << endl;
	cout << "OPTIONS:" << endl;
	cout << "If a long option shows an argument as mandatory," << endl;
	cout << "then it is also mandatory for the equivalent short option." << endl << endl;
	cout << "  -h, --help             display this help and exit" << endl;
	cout << "  -f, --list-frames      display all possible frames for id3v2" << endl;
	cout << "  -L, --list-genres      list all id3v1 genres" << endl;
	cout << "  -v, --version          display version information and exit" << endl;
	cout << "  -l, --list             list the tag(s) on the file(s)" << endl;
	cout << "  -R, --list-rfc822      list using an rfc822-style format for output" << endl;
	cout << "  -S, --delete-v2        delete id3v2 tags" << endl;
	cout << "  -s, --delete-v1        delete id3v1 tags" << endl;
	cout << "  -D, --delete-all       delete both id3v1 and id3v2 tags" << endl;
	cout << "  -C, --convert          convert id3v1 tag to id3v2" << endl;
	cout << "  -1, --id3v1-only       write only id3v1 tag" << endl;
	cout << "  -2, --id3v2-only       write only id3v2 tag" << endl;
	cout << "  -3, --write-all        write both id3v1 and id3v2 tag" << endl;
	cout << "  -x, --extract-apics    extract all attached pictures" << endl;
	cout << "  -d, --delimiter C      set the delimiter for multiple field option" << endl
	<< "                         arguments to the given character (default is '" << FIELD_DELIM << "')" << endl;
	cout << "  -r, --remove  ID       remove all frames with the given id" << endl;
	cout << "  -a, --artist  ARTIST   set the artist information" << endl;
	cout << "  -A, --album   ALBUM    set the album title information" << endl;
	cout << "  -t, --song    SONG     set the song title information" << endl;
	cout << "  -c, --comment COMMENT" << FIELD_DELIM << "DESCRIPTION" << FIELD_DELIM << "LANGUAGE"
	<< endl << "                         set the comment information (both"
	<< endl << "                         description and language optional)" << endl;    
	cout << "  -g, --genre   NUM      set the genre number" << endl;
	cout << "  -y, --year    NUM      set the year" << endl;
	cout << "  -T, --track   NUM/NUM  set the track number/(optional) total tracks" << endl;
	cout << endl;
	cout << "You can set the value of any id3v2 frame by using \"--FID\"" << endl;
	cout << "For example: " << endl;
	cout << "    " << sName << " --TIT3 'Monkey!' file.mp3" << endl;
	cout << "would set the \"Subtitle/Description\" frame to \"Monkey!\"." << endl;
	cout << "There are some frames with multiple fields:" << endl;
	cout << "    --COMM COMMENT" << FIELD_DELIM << "DESCRIPTION" << FIELD_DELIM << "LANGUAGE" << endl;
	cout << "    --TXXX TEXT" << FIELD_DELIM << "DESCRIPTION" << endl;
	cout << "    --WXXX URL" << FIELD_DELIM << "DESCRIPTION" << endl;
	cout << "Only the first field is mandatory, the others are optional." << endl;
	cout << "When using --APIC the argument has to be a file!" << endl;
	cout << endl;
	cout << "When using -i or --extract-apics all attached pictures are saved as" << endl;
	cout << "MP3FILENAME.apic-NUM.FORMAT in the same directory as the mp3 file." << endl;
	cout << endl;
}

extern void ListTag(int argc, char *argv[], int optind, int rfc822);
extern void PrintFrameHelp(char *sName);
extern void PrintGenreList();

#ifdef SORT_RUNTIME
extern void InitGenres();
#endif  // SORT_RUNTIME

int main( int argc, char *argv[]) {
	int ii;
	int frameCounter = 0, frameDelCounter = 0, argCounter = 0;
	int iOpt, iLongOpt, optFrameID, option_index;
	char tmp[TMPSIZE], fdelim = FIELD_DELIM;
	BOOL extract_apics = FALSE;
	FILE * fp;
	
	struct frameInfo {
		enum ID3_FrameID id;
		char *data;
	} frameList[MAXNOFRAMES];
	
	char* framesToDel[MAXNOFRAMES];
	
	static struct option long_options[] = { 
		// help and info
		{ "help",          no_argument, &iLongOpt, 'h' },
		{ "list-frames",   no_argument, &iLongOpt, 'f' },
		{ "list-genres",   no_argument, &iLongOpt, 'L' },
		{ "version",       no_argument, &iLongOpt, 'v' },
		// list / remove / convert
		{ "list",          no_argument, &iLongOpt, 'l' },
		{ "list-rfc822",   no_argument, &iLongOpt, 'R' },
		{ "delete-v2",     no_argument, &iLongOpt, 'd' },
		{ "delete-v1",     no_argument, &iLongOpt, 's' },
		{ "delete-all",    no_argument, &iLongOpt, 'D' },
		{ "convert",       no_argument, &iLongOpt, 'C' },
		{ "id3v1-only",    no_argument, &iLongOpt, '1' },
		{ "id3v2-only",    no_argument, &iLongOpt, '2' },
		{ "write-all",     no_argument, &iLongOpt, '3' },
		{ "extract-apics", no_argument, &iLongOpt, 'x' },
		{ "delimiter", required_argument, &iLongOpt, 'd' },
		{ "remove",    required_argument, &iLongOpt, 'r' },
		// infomation to tag
		{ "artist",    required_argument, &iLongOpt, 'a' },
		{ "album",     required_argument, &iLongOpt, 'A' },
		{ "song",      required_argument, &iLongOpt, 't' },
		{ "comment",   required_argument, &iLongOpt, 'c' },
		{ "genre",     required_argument, &iLongOpt, 'g' },
		{ "year",      required_argument, &iLongOpt, 'y' },
		{ "track",     required_argument, &iLongOpt, 'T' },
		{ frameTable[1].name,  required_argument, &optFrameID, ID3FID_AUDIOCRYPTO }, // AENC
		{ frameTable[2].name,  required_argument, &optFrameID, ID3FID_PICTURE }, // APIC
		{ frameTable[3].name,  required_argument, &optFrameID, ID3FID_COMMENT }, // COMM
			/* COMR too complex */
		{ frameTable[5].name,  required_argument, &optFrameID, ID3FID_CRYPTOREG }, // ENCR
		{ frameTable[6].name,  required_argument, &optFrameID, ID3FID_EQUALIZATION }, // EQUA
		{ frameTable[7].name,  required_argument, &optFrameID, ID3FID_EVENTTIMING }, // ETCO
		{ frameTable[8].name,  required_argument, &optFrameID, ID3FID_GENERALOBJECT }, // GEOB
		{ frameTable[9].name,  required_argument, &optFrameID, ID3FID_GROUPINGREG }, // GRID
		{ frameTable[10].name, required_argument, &optFrameID, ID3FID_INVOLVEDPEOPLE }, // IPLS
		{ frameTable[11].name, required_argument, &optFrameID, ID3FID_LINKEDINFO }, // LINK
		{ frameTable[12].name, required_argument, &optFrameID, ID3FID_CDID }, // MCDI
		{ frameTable[13].name, required_argument, &optFrameID, ID3FID_MPEGLOOKUP }, // MLLT
		{ frameTable[14].name, required_argument, &optFrameID, ID3FID_OWNERSHIP }, // OWNE
		{ frameTable[15].name, required_argument, &optFrameID, ID3FID_PRIVATE }, // PRIV
		{ frameTable[16].name, required_argument, &optFrameID, ID3FID_PLAYCOUNTER }, // PCNT
		{ frameTable[17].name, required_argument, &optFrameID, ID3FID_POPULARIMETER }, // POPM
		{ frameTable[18].name, required_argument, &optFrameID, ID3FID_POSITIONSYNC }, // POSS
		{ frameTable[19].name, required_argument, &optFrameID, ID3FID_BUFFERSIZE }, // RBUF
		{ frameTable[20].name, required_argument, &optFrameID, ID3FID_VOLUMEADJ }, // RVAD
		{ frameTable[21].name, required_argument, &optFrameID, ID3FID_REVERB }, // RVRB
		{ frameTable[22].name, required_argument, &optFrameID, ID3FID_SYNCEDLYRICS }, // SYLT
		{ frameTable[23].name, required_argument, &optFrameID, ID3FID_SYNCEDTEMPO }, // SYTC
		{ frameTable[24].name, required_argument, &optFrameID, ID3FID_ALBUM }, // TALB
		{ frameTable[25].name, required_argument, &optFrameID, ID3FID_BPM }, // TBPM
		{ frameTable[26].name, required_argument, &optFrameID, ID3FID_COMPOSER }, // TCOM
		{ frameTable[27].name, required_argument, &optFrameID, ID3FID_CONTENTTYPE }, // TCON
		{ frameTable[28].name, required_argument, &optFrameID, ID3FID_COPYRIGHT }, // TCOP
		{ frameTable[29].name, required_argument, &optFrameID, ID3FID_DATE }, // TDAT
		{ frameTable[30].name, required_argument, &optFrameID, ID3FID_PLAYLISTDELAY }, // TDLY
		{ frameTable[31].name, required_argument, &optFrameID, ID3FID_ENCODEDBY }, // TENC
		{ frameTable[32].name, required_argument, &optFrameID, ID3FID_LYRICIST }, // TEXT
		{ frameTable[33].name, required_argument, &optFrameID, ID3FID_FILETYPE }, // TFLT
		{ frameTable[34].name, required_argument, &optFrameID, ID3FID_TIME }, // TIME
		{ frameTable[35].name, required_argument, &optFrameID, ID3FID_CONTENTGROUP }, // TIT1
		{ frameTable[36].name, required_argument, &optFrameID, ID3FID_TITLE }, // TIT2
		{ frameTable[37].name, required_argument, &optFrameID, ID3FID_SUBTITLE }, // TIT3
		{ frameTable[38].name, required_argument, &optFrameID, ID3FID_INITIALKEY }, // TKEY
		{ frameTable[39].name, required_argument, &optFrameID, ID3FID_LANGUAGE }, // TLAN
		{ frameTable[40].name, required_argument, &optFrameID, ID3FID_SONGLEN }, // TLEN
		{ frameTable[41].name, required_argument, &optFrameID, ID3FID_MEDIATYPE }, // TMED
		{ frameTable[42].name, required_argument, &optFrameID, ID3FID_ORIGALBUM }, // TOAL
		{ frameTable[43].name, required_argument, &optFrameID, ID3FID_ORIGFILENAME }, // TOFN
		{ frameTable[44].name, required_argument, &optFrameID, ID3FID_ORIGLYRICIST }, // TOLY
		{ frameTable[45].name, required_argument, &optFrameID, ID3FID_ORIGARTIST }, // TOPE
		{ frameTable[46].name, required_argument, &optFrameID, ID3FID_ORIGYEAR }, // TORY
		{ frameTable[47].name, required_argument, &optFrameID, ID3FID_FILEOWNER }, // TOWN
		{ frameTable[48].name, required_argument, &optFrameID, ID3FID_LEADARTIST }, // TPE1
		{ frameTable[49].name, required_argument, &optFrameID, ID3FID_BAND }, // TPE2
		{ frameTable[50].name, required_argument, &optFrameID, ID3FID_CONDUCTOR }, // TPE3
		{ frameTable[51].name, required_argument, &optFrameID, ID3FID_MIXARTIST }, // TPE4
		{ frameTable[52].name, required_argument, &optFrameID, ID3FID_PARTINSET }, // TPOS
		{ frameTable[53].name, required_argument, &optFrameID, ID3FID_PUBLISHER }, // TPUB
		{ frameTable[54].name, required_argument, &optFrameID, ID3FID_TRACKNUM }, // TRCK
		{ frameTable[55].name, required_argument, &optFrameID, ID3FID_RECORDINGDATES }, // TRDA
		{ frameTable[56].name, required_argument, &optFrameID, ID3FID_NETRADIOSTATION }, // TRSN
		{ frameTable[57].name, required_argument, &optFrameID, ID3FID_NETRADIOOWNER }, // TRSO
		{ frameTable[58].name, required_argument, &optFrameID, ID3FID_SIZE }, // TSIZ
		{ frameTable[59].name, required_argument, &optFrameID, ID3FID_ISRC }, // TSRC
		{ frameTable[60].name, required_argument, &optFrameID, ID3FID_ENCODERSETTINGS }, // TSSE
		{ frameTable[61].name, required_argument, &optFrameID, ID3FID_USERTEXT }, // TXXX
		{ frameTable[62].name, required_argument, &optFrameID, ID3FID_YEAR }, // TYER
		{ frameTable[63].name, required_argument, &optFrameID, ID3FID_UNIQUEFILEID }, // UFID
		{ frameTable[64].name, required_argument, &optFrameID, ID3FID_TERMSOFUSE }, // USER
		{ frameTable[65].name, required_argument, &optFrameID, ID3FID_UNSYNCEDLYRICS }, // USLT
		{ frameTable[66].name, required_argument, &optFrameID, ID3FID_WWWCOMMERCIALINFO }, // WCOM
		{ frameTable[67].name, required_argument, &optFrameID, ID3FID_WWWCOPYRIGHT }, // WCOP
		{ frameTable[68].name, required_argument, &optFrameID, ID3FID_WWWAUDIOFILE }, // WOAF
		{ frameTable[69].name, required_argument, &optFrameID, ID3FID_WWWARTIST }, // WOAR
		{ frameTable[70].name, required_argument, &optFrameID, ID3FID_WWWAUDIOSOURCE }, // WOAS
		{ frameTable[71].name, required_argument, &optFrameID, ID3FID_WWWRADIOPAGE }, // WORS
		{ frameTable[72].name, required_argument, &optFrameID, ID3FID_WWWPAYMENT }, // WPAY
		{ frameTable[73].name, required_argument, &optFrameID, ID3FID_WWWPUBLISHER }, //WPUB
		{ frameTable[74].name, required_argument, &optFrameID, ID3FID_WWWUSER }, // WXXX
		{ 0, 0, 0, 0 }
	};
	
	while (TRUE) {
		option_index = 0;
		iLongOpt = 0;
		optFrameID = ID3FID_NOFRAME;
		
		iOpt = getopt_long(argc, argv, "123hfLvlRSsDCxd:r:a:A:t:c:g:y:T:", long_options, &option_index);
		
		if (iOpt == -1  && argCounter == 0) {
			if (argc > 1) {
				ListTag(argc, argv, 1, 0);
				exit(0);
			} else {
				cout << basename(argv[0]) << ": missing arguments" << endl;
				cout << "Try '" << basename(argv[0]) << " --help' for more information" << endl;
				exit(0);
			}
		} else if (iOpt == -1) {
			break;
		}
		argCounter++;
		
		if (iOpt == 0) {
			iOpt = iLongOpt;
		}
		
#ifdef SORT_RUNTIME
		InitGenres();
#endif  // SORT_RUNTIME
		
		switch (iOpt) {
			case 0: {
				frameList[frameCounter].id = (enum ID3_FrameID) optFrameID;
				frameList[frameCounter].data = optarg;
				frameCounter++;
				break;
			}
			case '?':
			case 'h': {
				PrintUsage(basename(argv[0]));
				exit(0);
			}
			case 'f': {
				PrintFrameHelp(basename(argv[0]));
				exit(0);
			}
			case 'L': {
				PrintGenreList();
				exit(0);
			}
			case 'v': {
				PrintVersion(basename(argv[0]));
				exit(0);
			}
			// listing / remove / convert -- see list.cpp and convert.cpp
			case 'l': {
				ListTag(argc, argv, optind, 0);
				exit(0);
			}
			case 'R': {
				ListTag(argc, argv, optind, 1);
				exit(0);
			}
			case 'S': {
				DeleteTag(argc, argv, optind, 2);
				exit(0);
			}
			case 's': {
				DeleteTag(argc, argv, optind, 1);
				exit(0);
			}
			case 'D': {
				DeleteTag(argc, argv, optind, 0);
				exit(0);
			}
			case 'C': {
				ConvertTag(argc, argv, optind);
				exit(0);
			}
			// which version of tag should be changed
			case '1': {
				UpdFlags = ID3TT_ID3V1;
				UpdFlagsCheck = TRUE;
				break;
			}
			case '2': {
				UpdFlags = ID3TT_ID3V2;
				UpdFlagsCheck = TRUE;
				break;
			}
			case '3': {
				UpdFlags = ID3TT_ALL;
				UpdFlagsCheck = TRUE;
				break;
			}
			// Tagging stuff
			case 'd': {
				if (strlen(optarg) == 1) {
					fdelim = optarg[0];
				} else {
					cout << "The argument of -d/--delimiter has to be a single character!" << endl << "Try '" 
					<< basename(argv[0]) << " --help' for more information" << endl;
					exit(2);
				}
				break;
			}
			case 'x': {
				extract_apics = TRUE;
				break;
			}
			case 'r': {
				framesToDel[frameDelCounter] = optarg;
				frameDelCounter++;
				break;
			}
			case 'a': {
				frameList[frameCounter].id   = ID3FID_LEADARTIST;
				frameList[frameCounter].data = optarg;
				frameCounter++;
				break;
			}
			case 'A': {
				frameList[frameCounter].id   = ID3FID_ALBUM;
				frameList[frameCounter].data = optarg;
				frameCounter++;
				break;
			}
			case 't': {
				frameList[frameCounter].id   = ID3FID_TITLE;
				frameList[frameCounter].data = optarg;
				frameCounter++;
				break;
			}
			case 'c': {
				frameList[frameCounter].id   = ID3FID_COMMENT;
				frameList[frameCounter].data = optarg;
				frameCounter++;
				break;
			}
			case 'g': {
				int genre_id = 255;
				char *genre_str;
				sscanf(optarg, "%d", &genre_id);
				if (genre_id == 255) {
					genre_id = GetNumFromGenre(optarg);
				}
				if (genre_id == 255) {
					genre_str = optarg;
				} else {
					sprintf(tmp, "(%d)", genre_id);
					genre_str = tmp;
				}
				frameList[frameCounter].id   = ID3FID_CONTENTTYPE;
				frameList[frameCounter].data = genre_str;
				frameCounter++;
				break;
			}
			case 'y': {
				frameList[frameCounter].id   = ID3FID_YEAR;
				frameList[frameCounter].data = optarg;
				frameCounter++;
				break;
			}
			case 'T': {
				frameList[frameCounter].id   = ID3FID_TRACKNUM;
				frameList[frameCounter].data = optarg;
				frameCounter++;
				break;
			// other tags
			}
			default: {
				cerr << "This isn't supposed to happen!" << endl;
				exit(1);
			}
		}
	}
	
	// loop through the files
	if (optind == argc) {
		cerr << "No file to work on!" << endl;
		exit(1);
	}
	
	for (size_t nIndex = optind; (unsigned int) nIndex < argc; nIndex++) {
		ID3_Tag myTag;
		struct stat filestat;
		luint nTags;
		
		// cludgy to check if we have the proper perms
		fp = fopen(argv[nIndex], "r+");
		if (fp == NULL) { // file didn't open
			fprintf(stderr, "%s: %s: ", basename(argv[0]), argv[nIndex]);
			perror(NULL);
			continue;
		}
		fclose(fp);
		
		// fix me - not checking to see if we can link to it
		if (stat(argv[nIndex], &filestat)) {
			cerr << "Could not stat file " << argv[nIndex] << endl;
			break;
		}
		
		size_t ret;
		ret = myTag.Link(argv[nIndex]);
		
		// if -1 and -2 options are not given on command line,
		// and file has only v1 or v2 tag, update only this
		if (!UpdFlagsCheck) {
			if (!myTag.HasV1Tag()) {
				UpdFlags = ID3TT_ID3V2;
			} else if (!myTag.HasV2Tag()) {
				UpdFlags = ID3TT_ID3V1;
			}
		}
		
		// loop through the frams we need to delete
		size_t num_removed = 0;
		ID3_Tag::Iterator *iter = (&myTag)->CreateIterator();
		ID3_Frame *frame = NULL;
		
		while ((frame = iter->GetNext()) != NULL) {
			for (ii = 0; ii < frameDelCounter; ii++) {
				if (strcmp(frame->GetTextID(), framesToDel[ii]) == 0) {
					frame = (&myTag)->RemoveFrame(frame);
					delete frame;
					num_removed++;
				}
			}
		}
		delete iter;
		if (num_removed > 0) cout << num_removed << " frame(s) removed from file " << argv[nIndex] << endl;
		
		//extract APICs
		if (extract_apics) {
			int num_extracted = 0;
			char *outftype, *outfile, *temp;
			const char *mimetype;
			ID3_Tag::Iterator *iter = (&myTag)->CreateIterator();
			ID3_Frame *frame = NULL;
			
			while ((frame = iter->GetNext()) != NULL) {
				if (frame->GetID() == ID3FID_PICTURE) {
					num_extracted++;
					mimetype = frame->GetField(ID3FN_MIMETYPE)->GetRawText();
					outftype = strrchr(mimetype, '/');
					if (outftype != NULL) {
						outftype++;
					} else {
						outftype = "bin";
					}
					int numlen = 2, numtemp = num_extracted / 10;
					while (numtemp /= 10) numlen++;
					
					size_t infnlen = strlen(argv[nIndex]);
					if ((outfile = (char*) malloc(infnlen + numlen + 12)) == NULL) exit(2);
					strcpy(outfile, argv[nIndex]);
					strcat(outfile, ".apic-");
					if ((temp = (char*) malloc(numlen + 1)) == NULL) exit(2);
					sprintf(temp, "%02d", num_extracted);
					strcat(outfile, temp);
					strcat(outfile, ".");
					strcat(outfile, outftype);
					
					frame->GetField(ID3FN_DATA)->ToFile(outfile);
					free(temp);
					free(outfile);
				}
			}
			delete iter;
			if (num_extracted > 0) cout << num_extracted << " APIC(s) extracted from file " << argv[nIndex] << endl;
		}
		
		// loop through the frames we need to add/modify
		for (ii = 0; ii < frameCounter; ii++) {
			ID3_FieldID TEXTorURL = ID3FN_URL;
			ID3_Frame *myFrame = NULL;
			myFrame = new ID3_Frame(frameList[ii].id);
			if (NULL == myFrame) {
				cout << "error: could not allocate memory\n" << endl;
				exit(1);
			}
			
			ID3_Frame *pFrame = NULL;
			pFrame = myTag.Find(frameList[ii].id);
			
			switch (frameList[ii].id) {
				case ID3FID_ALBUM:
				case ID3FID_BPM:
				case ID3FID_COMPOSER:
				case ID3FID_CONTENTTYPE:
				case ID3FID_COPYRIGHT:
				case ID3FID_DATE:
				case ID3FID_PLAYLISTDELAY:
				case ID3FID_ENCODEDBY:
				case ID3FID_LYRICIST:
				case ID3FID_FILETYPE:
				case ID3FID_TIME:
				case ID3FID_CONTENTGROUP:
				case ID3FID_TITLE:
				case ID3FID_SUBTITLE:
				case ID3FID_INITIALKEY:
				case ID3FID_LANGUAGE:
				case ID3FID_SONGLEN:
				case ID3FID_MEDIATYPE:
				case ID3FID_ORIGALBUM:
				case ID3FID_ORIGFILENAME:
				case ID3FID_ORIGLYRICIST:
				case ID3FID_ORIGARTIST:
				case ID3FID_ORIGYEAR:
				case ID3FID_FILEOWNER:
				case ID3FID_LEADARTIST:
				case ID3FID_BAND:
				case ID3FID_CONDUCTOR:
				case ID3FID_MIXARTIST:
				case ID3FID_PARTINSET:
				case ID3FID_PUBLISHER:
				case ID3FID_TRACKNUM: 
				case ID3FID_RECORDINGDATES:
				case ID3FID_NETRADIOSTATION:
				case ID3FID_NETRADIOOWNER:
				case ID3FID_SIZE:
				case ID3FID_ISRC:
				case ID3FID_ENCODERSETTINGS:
				case ID3FID_YEAR: {
					if (pFrame != NULL) {
						myTag.RemoveFrame(pFrame);
						delete pFrame;
					}
					if (strlen(frameList[ii].data) > 0) {
						myFrame->Field(ID3FN_TEXT) = frameList[ii].data;
						myTag.AttachFrame(myFrame);
					} else {
						delete myFrame;
					}
					break;
				}
				case ID3FID_USERTEXT: TEXTorURL = ID3FN_TEXT;
				case ID3FID_WWWUSER: {
					if (pFrame != NULL) {
						myTag.RemoveFrame(pFrame);
						delete pFrame;
					}
					
					// split the string at the delimiter!
					// if no delimiter then leave description empty
					char *delim;
					delim = strchr(frameList[ii].data, fdelim);
					if (delim == NULL) {
						myFrame->Field(TEXTorURL) = frameList[ii].data;
					} else {
						*delim++ = '\0';
						myFrame->Field(ID3FN_DESCRIPTION) = frameList[ii].data;
						myFrame->Field(TEXTorURL) = delim;
					}
					if (strlen(ID3_GetString(myFrame, TEXTorURL)) > 0) {
						myTag.AttachFrame(myFrame);
					} else {
						delete myFrame;
					}
					
					break;
				}
				case ID3FID_COMMENT:
				case ID3FID_UNSYNCEDLYRICS: {
					// split the string at the delimiter!
					// if no delimiter then leave desc/lang empty
					char *desc;
					desc = strchr(frameList[ii].data, fdelim);
					if (desc == NULL) {
						myFrame->Field(ID3FN_TEXT) = frameList[ii].data;
					} else {
						*desc++ = '\0';
						char *lang;
						lang = strchr(desc, fdelim);
						if (lang == NULL) {
							myFrame->Field(ID3FN_TEXT) = frameList[ii].data;
							myFrame->Field(ID3FN_DESCRIPTION) = desc;
						} else {
							*lang++ = '\0';
							myFrame->Field(ID3FN_TEXT) = frameList[ii].data;
							myFrame->Field(ID3FN_DESCRIPTION) = desc;
							myFrame->Field(ID3FN_LANGUAGE) = lang;
						}
					}
					
					// now try and find a comment/lyrics with the same descript 
					// and lang as what we have
					ID3_Frame *pFirstFrame = NULL;
					do {
						// if pFrame is NULL, either there were no comments/lyrics 
						// to begin with, or we removed them all in the process          
						if (pFrame == NULL) break;
						
						if (pFirstFrame == NULL) {
							pFirstFrame = pFrame;
						}
						
						char *tmp_desc = ID3_GetString(pFrame, ID3FN_DESCRIPTION);
						char *tmp_my_desc = ID3_GetString(myFrame, ID3FN_DESCRIPTION);
						char *tmp_lang = ID3_GetString(pFrame, ID3FN_LANGUAGE);
						char *tmp_my_lang = ID3_GetString(myFrame, ID3FN_LANGUAGE);
						if ((strcmp(tmp_desc, tmp_my_desc) == 0) && (strcmp(tmp_lang, tmp_my_lang) == 0)) {
							myTag.RemoveFrame(pFrame);
							delete pFrame;
							if (pFrame == pFirstFrame) {
								pFirstFrame = NULL;
							}
						}
						delete [] tmp_desc;
						delete [] tmp_my_desc;
						delete [] tmp_lang;
						delete [] tmp_my_lang;
						
						// get the next frame until it wraps around
					} while ((pFrame = myTag.Find(frameList[ii].id)) != pFirstFrame);
					
					if (strlen(ID3_GetString(myFrame, ID3FN_TEXT)) > 0) {
						myTag.AttachFrame(myFrame);
					} else {
						delete myFrame;
					}
					
					break;
				}
				case ID3FID_WWWAUDIOFILE:
				case ID3FID_WWWARTIST:
				case ID3FID_WWWAUDIOSOURCE:
				case ID3FID_WWWCOMMERCIALINFO:
				case ID3FID_WWWCOPYRIGHT:
				case ID3FID_WWWPUBLISHER:
				case ID3FID_WWWPAYMENT:
				case ID3FID_WWWRADIOPAGE: {
					if (pFrame != NULL) {
						myTag.RemoveFrame(pFrame);
						delete pFrame;
					}
					if (strlen(frameList[ii].data) > 0) {
						myFrame->Field(ID3FN_URL) = frameList[ii].data;
						myTag.AttachFrame(myFrame);
					} else {
						delete myFrame;
					}
					break;
				}
				case ID3FID_PICTURE: {
					char *mimetype, *command;
					FILE *fptr;
					fptr = fopen(frameList[ii].data, "r");
					if (fptr == NULL) {
						fprintf(stderr, "%s: %s: ", basename(argv[0]), frameList[ii].data);
						perror(NULL);
						frameList[ii].id = ID3FID_NOFRAME;
						break;
					}
					fclose(fptr);
					
					if ((mimetype = (char*) malloc(80)) == NULL) {
						cout << "error: could not allocate memory\n" << endl;
						exit(1);
					}
					if ((command = (char*) malloc(strlen(frameList[ii].data) + 12)) == NULL) {
						cout << "error: could not allocate memory\n" << endl;
						exit(1);
					}
					strcpy(command, "file -bi '");
					strcat(command, frameList[ii].data);
					strcat(command, "'");
					fptr = popen(command, "r");
					fgets(mimetype, 80, fptr);
					pclose(fptr);
					
					char *mttemp = strchr(mimetype, '\n');
					*mttemp = '\0';
					mttemp = strstr(mimetype, "image");
					if (mttemp == NULL) {
						cout << basename(argv[0]) << ": " << frameList[ii].data << ": wrong mime-type: " << mimetype << "! Not an image, not attached.\n";
						frameList[ii].id = ID3FID_NOFRAME;
						break;
					}
					myFrame->Field(ID3FN_MIMETYPE) = mimetype;
					myFrame->GetField(ID3FN_DATA)->FromFile(frameList[ii].data);
					myTag.AddFrame(myFrame);
					
					if (mimetype != NULL) free(mimetype);
					if (command != NULL) free(command);
					break;
				}
				case ID3FID_PLAYCOUNTER: {
					if (pFrame != NULL) {
						myTag.RemoveFrame(pFrame);
						delete pFrame;
					}
					if (strlen(frameList[ii].data) > 0) {
						int pcounter = atoi(frameList[ii].data);
						myFrame->Field(ID3FN_COUNTER) = pcounter;
						myTag.AddFrame(myFrame);
					} else {
						delete myFrame;
					}
					break;
				}
				case ID3FID_AUDIOCRYPTO:
				case ID3FID_CRYPTOREG:
				case ID3FID_EQUALIZATION:
				case ID3FID_EVENTTIMING:
				case ID3FID_GENERALOBJECT:
				case ID3FID_GROUPINGREG:
				case ID3FID_INVOLVEDPEOPLE:
				case ID3FID_CDID:
				case ID3FID_MPEGLOOKUP:
				case ID3FID_OWNERSHIP:
				case ID3FID_PRIVATE:
				case ID3FID_POPULARIMETER:
				case ID3FID_POSITIONSYNC:
				case ID3FID_BUFFERSIZE:
				case ID3FID_VOLUMEADJ:
				case ID3FID_REVERB:
				case ID3FID_SYNCEDLYRICS:
				case ID3FID_SYNCEDTEMPO:
				case ID3FID_UNIQUEFILEID: {
					cout << "Use of " << myFrame->GetTextID() << " still unimplemented. Sorry!" << endl;
					delete myFrame;
					break;
				}
				case ID3FID_NOFRAME:
				default: {
					break;
				}
			}
		} // steping through frames
		
		nTags = myTag.Update(UpdFlags);
		
		// update file with old mode
		chmod(argv[nIndex], filestat.st_mode);
	}
	
	return 0;
}
