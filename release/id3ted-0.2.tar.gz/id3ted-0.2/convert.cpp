#include <cstdio>
#include <cstdlib>
#include <id3/tag.h>

#include "convert.h"
#include "frametable.h"

using namespace std;

char* basename(char *string) {
	char *res = strrchr(string, '/');
	if (res == NULL) return string;
	return ++res;
}

void DeleteTag(int argc, char *argv[], int optind, int whichTags) {
	FILE *fp;
	
	for (size_t nIndex = optind; nIndex < argc; nIndex++) {
		/* cludgy to check if we have the proper perms */
		fp = fopen(argv[nIndex], "r+");
		if (fp == NULL) { /* file didn't open */
			fprintf(stderr, "%s: %s: ", basename(argv[0]), argv[nIndex]);
			perror(NULL);
			continue;	
		}
		fclose(fp);
		
		ID3_Tag myTag;
		
		cout << "Stripping id3 tag in \"";
		cout << argv[nIndex] << "\"... ";
		
		myTag.Clear();
		myTag.Link(argv[nIndex], ID3TT_ALL);
		
		luint nTags;
		switch(whichTags) {
			case 1: 
				nTags = myTag.Strip(ID3TT_ID3V1);
				cout << "id3v1 ";
				break;
			case 2:
				nTags = myTag.Strip(ID3TT_ID3V2);
				cout << "id3v2 ";
				break; 
			case 0:
			default:
				nTags = myTag.Strip(ID3TT_ID3);
				cout << "id3v1 and v2 ";
		}
		
		cout << "stripped." << endl;
	}

return;
}


void ConvertTag(int argc, char *argv[], int optind) {
	for (size_t nIndex = optind; nIndex < argc; nIndex++)	{
		ID3_Tag myTag;
		
		cout << "Converting id3v1 tag to id3v2 in ";
		cout << argv[nIndex] << "...";
		
		myTag.Clear();
		myTag.Link(argv[nIndex], ID3TT_ALL);
		
		luint nTags;
		
		nTags = myTag.Update(ID3TT_ID3V2);
		cout << " converted ";
		cout << endl;
	}
	
	return;
}

ID3_FrameID ConvertFName2FID(char *fname) {
	int a = 0;
	int b = frameTableCount;
	int i, cmp;
	
	while(a <= b) {
		i = (a + b) / 2;
		char *cmpwith = frameTable[i].name;
		cmp = strcmp(cmpwith, fname);
		
		if (cmp == 0) {
			return frameTable[i].fid;
		} else if (cmp < 0) {
			a = i + 1;
		} else {
			b = i - 1;
		}
	}
	
	return ID3FID_NOFRAME;
}

char* ConvertFID2FName(ID3_FrameID *frame_id) {
	int a = 0;
	int b = frameTableCount;
	int i, cmp;
	
	while(a <= b) {
		i = (a + b) / 2;
		ID3_FrameID cmpwith = frameTable[i].fid;
		
		if (cmpwith == *frame_id) {
			return frameTable[i].name;
		} else if (cmpwith < *frame_id) {
			a = i + 1;
		} else {
			b = i - 1;
		}
	}
	
	return "????";
}
